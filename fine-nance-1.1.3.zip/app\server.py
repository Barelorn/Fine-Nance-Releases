from __future__ import annotations

import csv
import smtplib
import ssl
import hashlib
import hmac
import io
import json
import os
import re
import sqlite3
import threading
import time
import uuid
import webbrowser
import subprocess
import tempfile
import urllib.request
import auth
import plaid_connector as plaid
from calendar import monthrange
from datetime import date, datetime, timedelta, timezone
from email.message import EmailMessage
from difflib import SequenceMatcher
from http import HTTPStatus
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, quote, unquote, urlparse, urljoin

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
STATIC = ROOT / "static"
DB = DATA / "finance.db"
DOCUMENTS = DATA / "documents"
MAX_DOCUMENT_BYTES = 15 * 1024 * 1024
MAX_JSON_BODY_BYTES = 2 * 1024 * 1024
HOST = os.environ.get("HF_HOST", "127.0.0.1")
PORT = int(os.environ.get("HF_PORT", "8765"))
AUTO_SYNC_HOURS = max(1,int(os.environ.get("HF_AUTO_SYNC_HOURS","6")))
PLAID_MODE = os.environ.get("PLAID_ENV", "sandbox").lower()
if PLAID_MODE not in ("sandbox", "production"):
    PLAID_MODE = "sandbox"
ALLOW_PRODUCTION = os.environ.get("HF_ALLOW_PRODUCTION", "false").lower() == "true"
PROFILE = os.environ.get("HF_PROFILE", "scott").lower()
APP_VERSION = (ROOT / "VERSION").read_text(encoding="utf-8").strip() if (ROOT / "VERSION").exists() else "0.0.0"
UPDATE_MANIFEST_URL = os.environ.get("HF_UPDATE_MANIFEST_URL", "").strip()

class RequestBodyError(ValueError):
    def __init__(self, message, status=400):
        super().__init__(message)
        self.status = status

def version_tuple(value): return tuple(int(x) for x in re.findall(r"\d+",str(value))[:3])
def fetch_update_manifest():
    if not UPDATE_MANIFEST_URL: return {"configured":False,"current_version":APP_VERSION,"update_available":False}
    separator="&" if "?" in UPDATE_MANIFEST_URL else "?"
    manifest_url=f"{UPDATE_MANIFEST_URL}{separator}checked={int(time.time())}"
    request=urllib.request.Request(manifest_url,headers={"User-Agent":"Fine-Nance-Updater/1.0","Cache-Control":"no-cache"})
    # ``utf-8-sig`` accepts standard UTF-8 and safely strips a BOM produced by
    # older Windows PowerShell versions.
    with urllib.request.urlopen(request,timeout=15) as response: manifest=json.loads(response.read(262144).decode("utf-8-sig"))
    latest=str(manifest.get("version","")).strip(); package=str(manifest.get("package_url","")).strip(); checksum=str(manifest.get("sha256","")).strip().lower()
    if not latest or not package or not re.fullmatch(r"[0-9a-f]{64}",checksum): raise ValueError("The update manifest is incomplete.")
    return {"configured":True,"current_version":APP_VERSION,"latest_version":latest,"update_available":version_tuple(latest)>version_tuple(APP_VERSION),"notes":str(manifest.get("notes",""))[:2000],"package_url":urljoin(UPDATE_MANIFEST_URL,package),"sha256":checksum}

CATEGORIES = ["Alcohol", "Automotive general", "Automotive repair", "Bar", "Camping & lodging", "Debt payment", "Dining out", "Entertainment", "Fees & interest", "Gas", "Gift", "Groceries", "Health", "Household & home improvement", "Housing", "Income", "Insurance", "Investment", "Other spending", "Personal transfers", "Pets", "Reimbursement", "Returned payment", "Shopping & household goods", "Software", "Subscriptions", "Tolls", "Transfer", "Transportation", "Utilities"]

BILLS = [
    ("PennyMac mortgage", "Housing", 2962.84, 1, "NFCU Bill Pay", "Off", "Current", "Next payment is the regular monthly payment; principal balance is not past due."),
    ("Pheasant Creek HOA", "Housing", 503.45, 1, "NFCU Bill Pay", "No", "Review", "Observed monthly payment for May-July 2026. Verify the unexplained increase against the next HOA statement; any separate ledger balance is tracked independently."),
    ("NFCU vehicle loan", "Transportation", 589.78, 27, "NFCU Bill Pay", "Transfer", "Essential", "Balance previously reported as $20,255.21 at 6.14% APR."),
    ("Reach Financial", "Loan", 549.52, None, "NFCU Bill Pay", "Yes", "High", "Two $274.76 monthly debits observed; update when the requested statement arrives."),
    ("Southern California Edison", "Utility", 165.42, 12, "NFCU Bill Pay", "Yes", "Essential", "Variable estimate; update from future bills."),
    ("Cox internet", "Utility", 100.00, 1, "NFCU Bill Pay", "Yes", "Essential", "Autopay."),
    ("USAA auto/property", "Insurance", 107.75, 7, "USAA Savings", "Yes", "Essential", "Funded by $120 direct deposit from each paycheck."),
    ("Consumer Cellular", "Utility", 39.76, 1, "USAA Scott's Checking", "Yes", "Essential", "Monthly cell-phone payment; observed posting from USAA Scott's Checking."),
    ("Stanford Rent", "Housing", 300.00, None, "NFCU Bill Pay", "Unknown", "Essential", "Scott's share of the Stanford home expenses for weekends and longer stays."),
    ("Netflix / Paramount / Amazon / Audible", "Subscription", 42.48, None, "Capital One Platinum", "Unknown", "Optional", "Target card for all subscriptions; confirm active services and update each vendor."),
    ("AAA Visa", "Credit Card", 41.00, 19, "Unconfirmed", "Scheduled", "High", "Balance reported $1,863.78."),
    ("Amazon Chase", "Credit Card", 131.00, 7, "Unconfirmed", "Unknown", "High", "Balance reported $2,224.11."),
    ("Capital One Platinum", "Credit Card", 74.00, 19, "Unconfirmed", "Unknown", "Over limit", "Balance reported $634.19."),
    ("Capital One Quicksilver", "Credit Card", 140.00, 20, "Unconfirmed", "Unknown", "Over limit", "Balance reported $4,109.20."),
    ("Mission Lane", "Credit Card", 219.50, 16, "NFCU Bill Pay", "Off", "Current", "Balance reported $1,895.74; no minimum due at last review."),
    ("Wells Fargo Micro Center", "Credit Card", 101.72, 21, "Unconfirmed", "Unknown", "Current", "Balance reported $276.68; no minimum due at last review."),
    ("Home Depot", "Credit Card", 36.00, 22, "NFCU Bill Pay", "Selected", "Near limit", "Balance reported $240.73."),
    ("IRS installment payment", "Taxes", 60.00, 1, "NFCU Bill Pay", "Yes", "Essential", "Direct debit from NFCU Bill Pay Savings. Nominally due on the 1st; weekend processing may post on the next business day."),
]

DEBTS = [
    ("PennyMac mortgage", "Mortgage", 412297.09, 2962.84, None, "Current", "The loan principal is not an amount currently due."),
    ("Reach Financial", "Personal loan", 16134.35, 549.52, 24.99, "Current", "Fixed 24.990% APR confirmed directly by Reach Financial customer service."),
    ("NFCU vehicle loan", "Auto loan", 20255.21, 589.78, 6.14, "Current", ""),
    ("AAA Visa", "Credit card", 1863.78, 41, None, "Current", ""),
    ("Amazon Chase", "Credit card", 2224.11, 131, None, "Review", "Portal previously displayed past-due messaging."),
    ("Capital One Platinum", "Credit card", 634.19, 74, None, "Over limit", ""),
    ("Capital One Quicksilver", "Credit card", 4109.20, 140, None, "Over limit", ""),
    ("Mission Lane", "Credit card", 1895.74, 0, None, "Current", ""),
    ("Wells Fargo Micro Center", "Credit card", 276.68, 0, None, "Current", ""),
    ("Home Depot", "Credit card", 240.73, 36, None, "Near limit", ""),
    ("IRS 2024 income tax", "Tax debt", 1623.59, 60, None, "Payment plan", "IRS transcript balance plus accruals as of 2026-08-24: $1,489.94 account balance, $95.83 accrued interest, and $37.82 accrued penalty. This is not a payoff amount. Direct-debit payments are current through August 2026, and a $588 credit from the 2025 return was transferred to the 2024 account on 2026-02-23."),
]

SCHEMA = """
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS accounts(id INTEGER PRIMARY KEY, name TEXT NOT NULL, institution TEXT, type TEXT NOT NULL, last4 TEXT, balance REAL DEFAULT 0, active INTEGER DEFAULT 1, notes TEXT);
CREATE TABLE IF NOT EXISTS bills(id INTEGER PRIMARY KEY, name TEXT NOT NULL, category TEXT, planned REAL NOT NULL, due_day INTEGER, paid_from TEXT, autopay TEXT, status TEXT, notes TEXT, active INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS debts(id INTEGER PRIMARY KEY, name TEXT NOT NULL, type TEXT, balance REAL NOT NULL, minimum REAL DEFAULT 0, apr REAL, status TEXT, notes TEXT);
CREATE TABLE IF NOT EXISTS transactions(id INTEGER PRIMARY KEY, tx_date TEXT NOT NULL, description TEXT NOT NULL, amount REAL NOT NULL, category TEXT, account TEXT, excluded INTEGER DEFAULT 0, source TEXT, fingerprint TEXT UNIQUE, notes TEXT);
CREATE TABLE IF NOT EXISTS investments(id INTEGER PRIMARY KEY, name TEXT NOT NULL, institution TEXT, balance REAL NOT NULL DEFAULT 0, contribution REAL DEFAULT 0, as_of TEXT, connection TEXT DEFAULT 'Manual', notes TEXT);
CREATE TABLE IF NOT EXISTS one_time_bills(id INTEGER PRIMARY KEY, name TEXT NOT NULL, amount REAL NOT NULL DEFAULT 0, due_date TEXT NOT NULL, category TEXT, paid_from TEXT, status TEXT DEFAULT 'Unpaid', notes TEXT, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS subscriptions(id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, amount REAL NOT NULL DEFAULT 0, frequency TEXT DEFAULT 'Monthly', paid_from TEXT, still_needed TEXT DEFAULT 'Review', cancellation_status TEXT DEFAULT 'None', last_seen TEXT, notes TEXT, active INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL, totp_secret TEXT NOT NULL, active INTEGER DEFAULT 1, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS sessions(id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, token_hash TEXT NOT NULL UNIQUE, csrf_token TEXT NOT NULL, expires_at TEXT NOT NULL, created_at TEXT NOT NULL, FOREIGN KEY(user_id) REFERENCES users(id));
CREATE TABLE IF NOT EXISTS connections(id INTEGER PRIMARY KEY, provider TEXT NOT NULL, environment TEXT NOT NULL DEFAULT 'sandbox', institution_id TEXT, institution_name TEXT NOT NULL, item_id TEXT NOT NULL UNIQUE, access_token_enc TEXT, status TEXT NOT NULL DEFAULT 'Active', cursor TEXT, last_sync TEXT, error TEXT, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS linked_accounts(id INTEGER PRIMARY KEY, connection_id INTEGER NOT NULL, provider_account_id TEXT NOT NULL UNIQUE, name TEXT NOT NULL, official_name TEXT, mask TEXT, type TEXT, subtype TEXT, current_balance REAL DEFAULT 0, available_balance REAL, currency TEXT DEFAULT 'USD', last_sync TEXT, local_account TEXT, import_mode TEXT NOT NULL DEFAULT 'review', cutover_date TEXT, FOREIGN KEY(connection_id) REFERENCES connections(id));
CREATE TABLE IF NOT EXISTS transaction_links(provider TEXT NOT NULL, external_id TEXT NOT NULL, transaction_id INTEGER NOT NULL, removed INTEGER DEFAULT 0, PRIMARY KEY(provider,external_id), FOREIGN KEY(transaction_id) REFERENCES transactions(id));
CREATE TABLE IF NOT EXISTS merchant_rules(id INTEGER PRIMARY KEY, merchant_key TEXT NOT NULL UNIQUE, sample_description TEXT NOT NULL, category TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS documents(id INTEGER PRIMARY KEY, original_name TEXT NOT NULL, stored_name TEXT NOT NULL UNIQUE, mime_type TEXT NOT NULL, size INTEGER NOT NULL, sha256 TEXT NOT NULL, document_type TEXT NOT NULL DEFAULT 'Other', payee TEXT, amount REAL, due_date TEXT, status TEXT NOT NULL DEFAULT 'Review', notes TEXT, folder_key TEXT NOT NULL DEFAULT '', one_time_bill_id INTEGER, active INTEGER NOT NULL DEFAULT 1, uploaded_at TEXT NOT NULL, FOREIGN KEY(one_time_bill_id) REFERENCES one_time_bills(id));
CREATE TABLE IF NOT EXISTS trips(id INTEGER PRIMARY KEY, name TEXT NOT NULL, start_date TEXT NOT NULL, end_date TEXT NOT NULL, location TEXT, notes TEXT, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS trip_transactions(trip_id INTEGER NOT NULL, transaction_id INTEGER NOT NULL, PRIMARY KEY(trip_id,transaction_id), FOREIGN KEY(trip_id) REFERENCES trips(id), FOREIGN KEY(transaction_id) REFERENCES transactions(id));
CREATE TABLE IF NOT EXISTS audit_reviews(finding_key TEXT PRIMARY KEY, status TEXT NOT NULL, notes TEXT, updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS notification_history(id INTEGER PRIMARY KEY, notification_type TEXT NOT NULL, recipient TEXT NOT NULL, subject TEXT NOT NULL, status TEXT NOT NULL, detail TEXT, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS register_entries(id INTEGER PRIMARY KEY, account TEXT NOT NULL, entry_date TEXT NOT NULL, description TEXT NOT NULL, amount REAL NOT NULL, category TEXT NOT NULL DEFAULT 'Other spending', notes TEXT, status TEXT NOT NULL DEFAULT 'Pending', matched_transaction_id INTEGER, created_at TEXT NOT NULL, matched_at TEXT, FOREIGN KEY(matched_transaction_id) REFERENCES transactions(id));
CREATE INDEX IF NOT EXISTS idx_register_pending_match ON register_entries(status,account,amount,entry_date);
"""

SUBSCRIPTIONS = [
    ("Acorns", 3.00, "Monthly", "USAA Scott's Checking", "Review", "None", "2026-08-10", "Monthly Acorns account subscription; keep separate from Acorns investment transfers."),
    ("Firewalla MSP Board", 4.99, "Yearly", "USAA Scott's Checking", "Yes", "None", "2026-08-05", "Annual subscription used to monitor Scott's firewall through the MSP Board."),
    ("Netflix", 8.99, "Monthly", "USAA Scott's Checking", "Review", "None", "2026-08-03", "Detected in imported transactions."),
    ("Audible", 14.95, "Monthly", "Capital One Platinum", "Review", "None", "2026-06-02", "Detected repeatedly on Capital One Platinum."),
    ("Disney+ via Roku", 12.99, "Monthly", "Capital One Platinum", "Review", "None", "2026-06-15", "Confirm whether it is still active."),
    ("Peacock via Roku", 10.99, "Monthly", "Capital One Platinum", "Review", "None", "2026-01-10", "Older last-seen date; verify current status."),
    ("Google Truecaller", 9.99, "Monthly", "USAA Scott's Checking", "Review", "None", "2026-07-01", "Detected in imported transactions."),
    ("Google Family Shared", 39.99, "Monthly", "USAA Scott's Checking", "Review", "None", "2026-06-26", "Confirm the service represented by this charge."),
    ("GameFly", 15.09, "Monthly", "USAA Scott's Checking", "Review", "None", "2026-01-12", "Older last-seen date; verify current status."),
    ("DVDInbox.com", 19.99, "Monthly", "USAA Scott's Checking", "Review", "None", "2026-01-12", "Older last-seen date; verify current status."),
]

def conn():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

GENERAL_DOCUMENT_FOLDERS = (
    ("general:vehicle-dmv", "DMV & vehicle records", "General records", "Registrations, titles, and DMV notices"),
    ("general:home-property", "Home & property", "General records", "HOA and property records outside the mortgage"),
    ("general:insurance", "Insurance", "General records", "Auto, home, and other insurance policies"),
    ("general:taxes", "Taxes", "General records", "IRS, state tax, and tax-return records"),
    ("general:identity-legal", "Identity & legal", "General records", "Licenses, identification, and legal records"),
    ("general:medical", "Medical", "General records", "Medical bills and health records"),
    ("general:income-employment", "Income & employment", "General records", "Pay statements and employment records"),
    ("general:receipts-warranties", "Receipts & warranties", "General records", "Purchase records and warranty paperwork"),
    ("general:general", "General documents", "General records", "Anything that does not fit another folder"),
)

def document_name_key(value):
    value=re.sub(r"[^a-z0-9]+"," ",str(value or "").lower())
    return " ".join(x for x in value.split() if x not in {"the","consumer","credit","card","account"})

def document_account_names_match(candidate,existing):
    """Match a provider's account alias to an existing debt without merging sibling cards."""
    if not candidate or not existing: return False
    if candidate==existing or (len(candidate)>5 and (candidate in existing or existing in candidate)): return True
    institution_words={"american","bank","capital","chase","citi","citibank","comenity","express","fargo","federal","financial","navy","new","one","union","usaa","wells"}
    candidate_tokens=set(candidate.split())-institution_words
    existing_tokens=set(existing.split())-institution_words
    return len(candidate_tokens & existing_tokens)>=2

def document_folders(connection=None):
    """Return the live document filing cabinet. New debts/accounts appear automatically."""
    close=connection is None; c=connection or conn()
    try:
        folders=[]; seen_names=set()
        for debt in c.execute("SELECT id,name,type FROM debts ORDER BY name"):
            debt_type=str(debt["type"] or "").lower()
            if "credit" in debt_type: group="Credit cards"
            elif "mortgage" in debt_type or "loan" in debt_type: group="Mortgages & loans"
            elif "tax" in debt_type: continue
            else: group="Other accounts"
            folders.append({"key":f'debt:{debt["id"]}',"name":debt["name"],"group":group,"subtitle":debt["type"] or "Financial account"})
            seen_names.add(document_name_key(debt["name"]))
        for account in c.execute("SELECT id,name,official_name,type,subtype,mask FROM linked_accounts ORDER BY name"):
            kind=" ".join(str(account[x] or "") for x in ("type","subtype")).lower()
            if not any(x in kind for x in ("credit","loan","mortgage")): continue
            name=account["official_name"] or account["name"]
            account_names={document_name_key(name),document_name_key(account["name"])}
            aliases={"prime visa":"amazon chase","platinum":"capital one platinum","quicksilver":"capital one quicksilver"}
            account_names.update(aliases.get(candidate,"") for candidate in tuple(account_names))
            if any(document_account_names_match(candidate,seen) for candidate in account_names for seen in seen_names): continue
            group="Credit cards" if "credit" in kind else "Mortgages & loans" if any(x in kind for x in ("loan","mortgage")) else "Other accounts"
            mask=f" •••• {account['mask']}" if account["mask"] else ""
            folders.append({"key":f'account:{account["id"]}',"name":name,"group":group,"subtitle":f"Connected account{mask}"})
            seen_names.add(document_name_key(name))
        folders.extend({"key":key,"name":name,"group":group,"subtitle":subtitle} for key,name,group,subtitle in GENERAL_DOCUMENT_FOLDERS)
        known={x["key"] for x in folders}
        for row in c.execute("SELECT DISTINCT folder_key FROM documents WHERE active=1 AND folder_key<>''"):
            key=row["folder_key"]
            if key not in known:
                folders.append({"key":key,"name":"Archived account documents","group":"Other accounts","subtitle":"Documents retained from an older account"})
        return folders
    finally:
        if close: c.close()

def infer_document_folder(document, connection=None):
    """Choose a conservative folder using account names first, then document keywords."""
    close=connection is None; c=connection or conn()
    try:
        text=" ".join(str(document.get(x) or "") for x in ("original_name","payee","document_type","notes")).lower()
        compact=document_name_key(text)
        debts=list(c.execute("SELECT id,name,type FROM debts ORDER BY LENGTH(name) DESC"))
        aliases={
            "pennymac":"pennymac", "home depot":"home depot", "micro center":"micro center",
            "reach financial":"reach financial", "mission lane":"mission lane", "amazon chase":"amazon chase",
            "quicksilver":"quicksilver", "capital one platinum":"capital one platinum", "aaa visa":"aaa visa",
        }
        for debt in debts:
            debt_key=document_name_key(debt["name"])
            candidates={debt_key}
            candidates.update(alias for alias,target in aliases.items() if target in debt_key)
            if any(candidate and candidate in compact for candidate in candidates): return f'debt:{debt["id"]}'
        if any(x in text for x in ("dmv","registration","vehicle title","license plate")): return "general:vehicle-dmv"
        if any(x in text for x in ("insurance","policy","coverage","homeowner")): return "general:insurance"
        if any(x in text for x in ("irs","tax","transcript","1099","w-2","w2")): return "general:taxes"
        if any(x in text for x in ("hoa","property","home inspection","deed")): return "general:home-property"
        if any(x in text for x in ("passport","driver license","identification","legal")): return "general:identity-legal"
        if any(x in text for x in ("medical","doctor","hospital","dental","health")): return "general:medical"
        if any(x in text for x in ("paystub","pay stub","employment","salary")): return "general:income-employment"
        if any(x in text for x in ("receipt","warranty","purchase record")): return "general:receipts-warranties"
        return "general:general"
    finally:
        if close: c.close()

EMAIL_SETTING_KEYS=("email_enabled","email_sender","email_recipient","email_smtp_host","email_smtp_port","email_reminder_days","email_last_reminder_date")

def email_settings(connection=None):
    close=connection is None; c=connection or conn()
    try:
        values={x["key"]:x["value"] for x in c.execute("SELECT key,value FROM settings WHERE key IN (%s)" % ",".join("?"*len(EMAIL_SETTING_KEYS)),EMAIL_SETTING_KEYS)}
        return {
            "enabled":values.get("email_enabled","false").lower()=="true",
            "sender":values.get("email_sender",""), "recipient":values.get("email_recipient",""),
            "host":values.get("email_smtp_host","smtp.gmail.com"), "port":int(values.get("email_smtp_port","587")),
            "reminder_days":int(values.get("email_reminder_days","7")),
            "password_saved":bool(c.execute("SELECT 1 FROM settings WHERE key='email_password_enc'").fetchone()),
        }
    finally:
        if close: c.close()

def save_email_settings(values,password=""):
    from cryptography.fernet import Fernet
    with conn() as c:
        pairs={
            "email_enabled":"true" if values.get("enabled") else "false", "email_sender":values["sender"],
            "email_recipient":values["recipient"], "email_smtp_host":values.get("host","smtp.gmail.com"),
            "email_smtp_port":str(int(values.get("port",587))), "email_reminder_days":str(int(values.get("reminder_days",7))),
        }
        for key,value in pairs.items(): c.execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(key,value))
        if password:
            key=os.environ.get("HF_TOKEN_KEY")
            if not key: raise ValueError("The VM encryption key is not configured.")
            encrypted=Fernet(key.encode()).encrypt(password.encode()).decode()
            c.execute("INSERT INTO settings(key,value) VALUES('email_password_enc',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(encrypted,))

def email_password():
    from cryptography.fernet import Fernet,InvalidToken
    found=rows("SELECT value FROM settings WHERE key='email_password_enc'")
    try: return Fernet(os.environ["HF_TOKEN_KEY"].encode()).decrypt(found[0]["value"].encode()).decode()
    except (IndexError,KeyError,ValueError,InvalidToken): raise ValueError("The saved Gmail app password is unavailable.") from None

def record_notification(kind,recipient,subject,status,detail=""):
    with conn() as c: c.execute("INSERT INTO notification_history(notification_type,recipient,subject,status,detail,created_at) VALUES(?,?,?,?,?,?)",(kind,recipient,subject,status,str(detail)[:1000],datetime.now(timezone.utc).isoformat()))

def send_email(subject,text,kind="Test"):
    cfg=email_settings(); recipient=cfg["recipient"]
    if not cfg["sender"] or not recipient: raise ValueError("Sender and recipient addresses are required.")
    message=EmailMessage(); message["From"]=cfg["sender"]; message["To"]=recipient; message["Subject"]=subject; message.set_content(text)
    try:
        context=ssl.create_default_context()
        if cfg["port"]==465:
            with smtplib.SMTP_SSL(cfg["host"],cfg["port"],timeout=25,context=context) as smtp: smtp.login(cfg["sender"],email_password()); smtp.send_message(message)
        else:
            with smtplib.SMTP(cfg["host"],cfg["port"],timeout=25) as smtp: smtp.ehlo(); smtp.starttls(context=context); smtp.ehlo(); smtp.login(cfg["sender"],email_password()); smtp.send_message(message)
        record_notification(kind,recipient,subject,"Sent"); return True
    except Exception as exc:
        record_notification(kind,recipient,subject,"Failed",exc); raise

def send_due_bill_reminders(force=False):
    cfg=email_settings()
    if not cfg["enabled"] and not force: return False
    today=date.today(); setting=rows("SELECT value FROM settings WHERE key='email_last_reminder_date'")
    if not force and setting and setting[0]["value"]==today.isoformat(): return False
    cutoff=date.fromordinal(today.toordinal()+cfg["reminder_days"])
    upcoming=rows("SELECT name,amount,due_date,status FROM one_time_bills WHERE status!='Paid' AND due_date BETWEEN ? AND ? ORDER BY due_date",(today.isoformat(),cutoff.isoformat()))
    recurring=[]
    for bill in rows("SELECT name,planned,due_day,status FROM bills WHERE active=1 AND due_day IS NOT NULL ORDER BY due_day"):
        for year,month in ((today.year,today.month), ((today.year+today.month//12),(today.month%12)+1)):
            due=date(year,month,min(int(bill["due_day"]),monthrange(year,month)[1]))
            if today<=due<=cutoff: recurring.append({"name":bill["name"],"amount":bill["planned"],"due_date":due.isoformat(),"status":bill["status"]})
    items=[dict(x) for x in upcoming]+recurring
    if items:
        lines=[f"The following Fine Nance bills are due within {cfg['reminder_days']} days:",""]+[f"- {x['due_date']}: {x['name']} (${float(x['amount']):,.2f}) — {x['status']}" for x in sorted(items,key=lambda x:x["due_date"])]
        send_email(f"Fine Nance: {len(items)} upcoming bill{'s' if len(items)!=1 else ''}","\n".join(lines)+"\n\nFine Nance does not make payments automatically.","Bill reminder")
    with conn() as c: c.execute("INSERT INTO settings(key,value) VALUES('email_last_reminder_date',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(today.isoformat(),))
    return bool(items)

def email_reminder_loop():
    while True:
        try: send_due_bill_reminders()
        except Exception: pass
        time.sleep(3600)

MERCHANT_RULE_CACHE = {}

def merchant_key(description):
    """Create a stable key for recurring merchant descriptions without storing credentials."""
    value = str(description or "").upper()
    value = re.sub(r"\b(?:ACH TRANSACTION|ACH DEBIT|DEBIT CARD|CARD PURCHASE|PURCHASE)\b", " ", value)
    value = re.sub(r"\bXX\d+\b|\*+[A-Z0-9]+|\b\d{5,}\b", " ", value)
    value = re.sub(r"[^A-Z0-9]+", " ", value)
    return " ".join(value.split())[:160]

def refresh_merchant_rules(connection=None):
    global MERCHANT_RULE_CACHE
    try:
        if connection is None:
            with conn() as c:
                MERCHANT_RULE_CACHE = {x["merchant_key"]: x["category"] for x in c.execute("SELECT merchant_key,category FROM merchant_rules")}
        else:
            MERCHANT_RULE_CACHE = {x["merchant_key"]: x["category"] for x in connection.execute("SELECT merchant_key,category FROM merchant_rules")}
    except sqlite3.Error:
        MERCHANT_RULE_CACHE = {}

def init_db():
    DATA.mkdir(exist_ok=True)
    DOCUMENTS.mkdir(exist_ok=True)
    try: os.chmod(DOCUMENTS,0o700)
    except OSError: pass
    with conn() as c:
        c.executescript(SCHEMA)
        connection_columns={x[1] for x in c.execute("PRAGMA table_info(connections)")}
        if "institution_id" not in connection_columns: c.execute("ALTER TABLE connections ADD COLUMN institution_id TEXT")
        if "access_token_enc" not in connection_columns: c.execute("ALTER TABLE connections ADD COLUMN access_token_enc TEXT")
        linked_columns={x[1] for x in c.execute("PRAGMA table_info(linked_accounts)")}
        if "local_account" not in linked_columns: c.execute("ALTER TABLE linked_accounts ADD COLUMN local_account TEXT")
        if "import_mode" not in linked_columns: c.execute("ALTER TABLE linked_accounts ADD COLUMN import_mode TEXT NOT NULL DEFAULT 'review'")
        if "cutover_date" not in linked_columns: c.execute("ALTER TABLE linked_accounts ADD COLUMN cutover_date TEXT")
        transaction_columns={x[1] for x in c.execute("PRAGMA table_info(transactions)")}
        if "notes" not in transaction_columns: c.execute("ALTER TABLE transactions ADD COLUMN notes TEXT")
        document_columns={x[1] for x in c.execute("PRAGMA table_info(documents)")}
        if "folder_key" not in document_columns: c.execute("ALTER TABLE documents ADD COLUMN folder_key TEXT NOT NULL DEFAULT ''")
        if PROFILE != "blank" and not c.execute("SELECT 1 FROM bills LIMIT 1").fetchone():
            c.executemany("INSERT INTO bills(name,category,planned,due_day,paid_from,autopay,status,notes) VALUES(?,?,?,?,?,?,?,?)", BILLS)
        if PROFILE != "blank" and not c.execute("SELECT 1 FROM debts LIMIT 1").fetchone():
            c.executemany("INSERT INTO debts(name,type,balance,minimum,apr,status,notes) VALUES(?,?,?,?,?,?,?)", DEBTS)
        if PROFILE != "blank" and not c.execute("SELECT 1 FROM investments LIMIT 1").fetchone():
            c.execute("INSERT INTO investments(name,institution,balance,contribution,as_of,connection,notes) VALUES(?,?,?,?,?,?,?)", ("Acorns", "Acorns", 0, 0, date.today().isoformat(), "Manual", "Enter the current balance until a supported aggregator connection is configured."))
        if PROFILE != "blank" and not c.execute("SELECT 1 FROM subscriptions LIMIT 1").fetchone():
            c.executemany("INSERT INTO subscriptions(name,amount,frequency,paid_from,still_needed,cancellation_status,last_seen,notes) VALUES(?,?,?,?,?,?,?,?)", SUBSCRIPTIONS)
        c.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('bill_buffer','250')")
        if PROFILE == "blank":
            c.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('va_monthly_income','0')")
            c.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('va_income_permanent','false')")
            c.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('usaa_savings_per_paycheck','0')")
        else:
            c.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('va_monthly_income','1672.85')")
            c.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('va_income_permanent','true')")
            c.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('usaa_savings_per_paycheck','120')")
        for document in c.execute("SELECT * FROM documents WHERE active=1 AND COALESCE(folder_key,'')='' ").fetchall():
            c.execute("UPDATE documents SET folder_key=? WHERE id=?",(infer_document_folder(dict(document),c),document["id"]))
        refresh_merchant_rules(c)
    seed_spending()

def seed_spending():
    # The extracted-statement seed is only for a brand-new empty database.
    # Once official CSV exports are present it must never repopulate overlaps.
    if PROFILE == "blank": return
    with conn() as c:
        if c.execute("SELECT 1 FROM transactions LIMIT 1").fetchone(): return
    source = ROOT.parent / "tmp" / "spending_analysis.json"
    if not source.exists(): return
    try: records = json.loads(source.read_text(encoding="utf-8"))["records"]
    except Exception: return
    rows=[]
    for r in records:
        cat=r.get("category", "Other spending")
        excluded=1 if cat.startswith("Exclude:") else 0
        mmdd=r.get("date", "")
        try:
            m,d=map(int,mmdd.split("/")); txd=f"2026-{m:02d}-{d:02d}"
        except Exception: continue
        desc=" ".join(r.get("description","").split())
        fp=hashlib.sha256(f"{txd}|{desc}|{r.get('amount')}|statement-review".encode()).hexdigest()
        rows.append((txd,desc,float(r.get("amount",0)),cat,"USAA Scott's Checking",excluded,"Reviewed statements",fp))
    with conn() as c:
        c.executemany("INSERT OR IGNORE INTO transactions(tx_date,description,amount,category,account,excluded,source,fingerprint) VALUES(?,?,?,?,?,?,?,?)",rows)

def rows(query, args=()):
    with conn() as c: return [dict(x) for x in c.execute(query,args).fetchall()]

NON_SPENDING_CATEGORIES = {"Transfer","Income","Debt payment","Investment","Reimbursement","Returned payment"}

def reconcile_register():
    """Match receipt-register entries to one unambiguous posted transaction.

    Register entries never become transactions themselves.  This keeps the
    spending reports accurate while still allowing a receipt to reduce the
    projected checking balance before the institution posts it.
    """
    now=datetime.now(timezone.utc).isoformat(); matched=0
    with conn() as c:
        pending=c.execute("SELECT * FROM register_entries WHERE status='Pending' ORDER BY entry_date,id").fetchall()
        for entry in pending:
            try: entry_day=date.fromisoformat(entry["entry_date"])
            except (TypeError,ValueError): continue
            start=(entry_day-timedelta(days=5)).isoformat(); end=(entry_day+timedelta(days=5)).isoformat(); cents=round(float(entry["amount"])*100)
            candidates=c.execute("""SELECT id,tx_date FROM transactions
                WHERE account=? AND excluded=0 AND tx_date BETWEEN ? AND ?
                  AND CAST(ROUND(amount*100) AS INTEGER)=?
                  AND id NOT IN (SELECT matched_transaction_id FROM register_entries WHERE matched_transaction_id IS NOT NULL)
                ORDER BY tx_date,id""",(entry["account"],start,end,cents)).fetchall()
            if len(candidates)!=1: continue
            candidate=candidates[0]; candidate_day=date.fromisoformat(candidate["tx_date"])
            candidate_start=(candidate_day-timedelta(days=5)).isoformat(); candidate_end=(candidate_day+timedelta(days=5)).isoformat()
            competing=c.execute("""SELECT id FROM register_entries
                WHERE status='Pending' AND account=? AND entry_date BETWEEN ? AND ?
                  AND CAST(ROUND(amount*100) AS INTEGER)=?""",(entry["account"],candidate_start,candidate_end,cents)).fetchall()
            if len(competing)!=1: continue
            note=(entry["notes"] or "").strip()
            c.execute("UPDATE transactions SET category=?,notes=CASE WHEN ?<>'' THEN ? ELSE notes END WHERE id=?",(entry["category"],note,note,candidate["id"]))
            c.execute("UPDATE register_entries SET status='Matched',matched_transaction_id=?,matched_at=? WHERE id=?",(candidate["id"],now,entry["id"]))
            matched+=1
    return matched

def register_account_summaries():
    """Return the user's USAA/NFCU checking accounts and projected balances."""
    found={}
    def add(name,institution="",balance=None,as_of=None):
        name=(name or "").strip(); institution=(institution or "").strip()
        combined=f"{name} {institution}".upper()
        if not name or not re.search(r"USAA|NAVY FEDERAL|\bNFCU\b",combined): return
        if re.search(r"CREDIT|CARD|LOAN|MORTGAGE",combined): return
        key=name.casefold()
        current=found.get(key,{"name":name,"institution":institution,"postedBalance":None,"balanceAsOf":as_of})
        if balance is not None: current["postedBalance"]=round(float(balance),2)
        if institution: current["institution"]=institution
        if as_of: current["balanceAsOf"]=as_of
        found[key]=current
    for item in rows("""SELECT l.name,l.local_account,l.type,l.subtype,l.current_balance,l.last_sync,c.institution_name
        FROM linked_accounts l JOIN connections c ON c.id=l.connection_id
        WHERE c.environment='production' ORDER BY c.institution_name,l.name"""):
        kind=f"{item.get('type') or ''} {item.get('subtype') or ''}".lower()
        if "checking" not in kind: continue
        add(item.get("local_account") or item.get("name"),item.get("institution_name"),item.get("current_balance"),item.get("last_sync"))
    for item in rows("SELECT name,institution,type,balance FROM accounts WHERE active=1 ORDER BY name"):
        if "checking" not in str(item.get("type") or "").lower(): continue
        add(item.get("name"),item.get("institution"),item.get("balance"),None)
    for item in rows("""SELECT DISTINCT account FROM transactions
        WHERE account IS NOT NULL AND UPPER(account) LIKE '%CHECKING%' ORDER BY account"""):
        add(item.get("account"),"",None,None)
    totals={r["account"]:r for r in rows("""SELECT account,
        SUM(CASE WHEN status='Pending' THEN amount ELSE 0 END) pending_amount,
        SUM(CASE WHEN status='Pending' THEN 1 ELSE 0 END) pending_count,
        SUM(CASE WHEN status='Matched' THEN 1 ELSE 0 END) matched_count
        FROM register_entries GROUP BY account""")}
    result=[]
    for item in found.values():
        total=totals.get(item["name"],{}); pending=round(float(total.get("pending_amount") or 0),2); posted=item.get("postedBalance")
        item.update({"pendingAmount":pending,"pendingCount":int(total.get("pending_count") or 0),"matchedCount":int(total.get("matched_count") or 0),"projectedBalance":round(posted-pending,2) if posted is not None else None})
        result.append(item)
    return sorted(result,key=lambda x:(x.get("institution") or "",x["name"]))

def audit_merchant_key(description):
    """Normalize a description enough to compare statement and Plaid copies."""
    value=str(description or "").upper()
    value=re.sub(r"\b(?:ACH|POS|DEBIT|CREDIT|PURCHASE|TRANSACTION|CHECKCARD|VISA|MC|SQ|TST|DD)\b", " ", value)
    value=re.sub(r"\b(?:CA|NY|NJ|UT|TX|FL|WA|IL)\b|\b\d{4,}\b", " ", value)
    value=re.sub(r"[^A-Z0-9&]+", " ", value)
    return " ".join(value.split())[:120]

def audit_merchant_match(left,right):
    a,b=audit_merchant_key(left),audit_merchant_key(right)
    if not a or not b: return False
    if a==b or (min(len(a),len(b))>=8 and (a in b or b in a)): return True
    at,bt=set(a.split()),set(b.split())
    overlap=len(at&bt)/max(1,len(at|bt))
    return overlap>=0.55 or SequenceMatcher(None,a,b).ratio()>=0.78

def audit_findings():
    """Return review-first findings; no transaction is changed by scanning."""
    with conn() as c:
        ignored={x["finding_key"] for x in c.execute("SELECT finding_key FROM audit_reviews WHERE status='Ignored'")}
        findings=[]
        for tx in c.execute("SELECT * FROM transactions WHERE excluded=0 AND category='Other spending' ORDER BY tx_date DESC,id DESC"):
            key=f"other:{tx['id']}"
            if key not in ignored:
                findings.append({"key":key,"type":"uncategorized","severity":"review","title":"Category needs review","detail":tx["description"],"transactionId":tx["id"],"date":tx["tx_date"],"account":tx["account"],"amount":tx["amount"]})
        for tx in c.execute("SELECT * FROM transactions WHERE excluded=0"):
            if tx["category"] in NON_SPENDING_CATEGORIES:
                key=f"counted-nonspending:{tx['id']}"
                if key not in ignored:
                    findings.append({"key":key,"type":"counted_nonspending","severity":"urgent","title":"Non-spending item is counted","detail":tx["description"],"transactionId":tx["id"],"date":tx["tx_date"],"account":tx["account"],"amount":tx["amount"]})
        candidates=[dict(x) for x in c.execute("SELECT * FROM transactions WHERE excluded=0 ORDER BY account,amount,tx_date,id")]
        grouped={}
        for tx in candidates: grouped.setdefault((tx["account"],round(float(tx["amount"]),2)),[]).append(tx)
        seen=set()
        for group in grouped.values():
            for index,left in enumerate(group):
                for right in group[index+1:]:
                    if left["source"]==right["source"]: continue
                    try: days=abs((date.fromisoformat(left["tx_date"])-date.fromisoformat(right["tx_date"])).days)
                    except ValueError: continue
                    if days>3 or not audit_merchant_match(left["description"],right["description"]): continue
                    pair=tuple(sorted((left["id"],right["id"]))); key=f"duplicate:{pair[0]}:{pair[1]}"
                    if pair in seen or key in ignored: continue
                    seen.add(pair)
                    # Prefer retaining statement/import history and excluding a Plaid copy.
                    suggested=right if "PLAID" in (right["source"] or "").upper() else left if "PLAID" in (left["source"] or "").upper() else right
                    findings.append({"key":key,"type":"possible_duplicate","severity":"urgent","title":"Possible duplicate transaction","detail":f"{left['description']} / {right['description']}","transactionId":suggested["id"],"relatedTransactionIds":[left["id"],right["id"]],"date":left["tx_date"],"account":left["account"],"amount":left["amount"],"sources":[left["source"],right["source"]]})
        findings.sort(key=lambda x:(0 if x["severity"]=="urgent" else 1,x.get("date","") ),reverse=False)
        return findings

def document_file_type(data):
    """Return a trusted extension and MIME type based on file contents."""
    if data.startswith(b"%PDF-"): return ".pdf","application/pdf"
    if data.startswith(b"\x89PNG\r\n\x1a\n"): return ".png","image/png"
    if data.startswith(b"\xff\xd8\xff"): return ".jpg","image/jpeg"
    if len(data)>=12 and data[:4]==b"RIFF" and data[8:12]==b"WEBP": return ".webp","image/webp"
    return None

def demo_sandbox_sync():
    """Create deterministic fake aggregator data. Safe to run repeatedly."""
    now=datetime.now(timezone.utc).isoformat()
    demo_accounts=[
        ("demo-checking","Everyday Checking","Plaid Sandbox Checking","1111","depository","checking",2842.17,2717.17),
        ("demo-savings","Bill Pay Savings","Plaid Sandbox Savings","2222","depository","savings",6415.23,6415.23),
        ("demo-card","Rewards Credit Card","Plaid Sandbox Credit Card","3333","credit","credit card",486.72,4513.28),
    ]
    demo_transactions=[
        ("demo-tx-ralphs",date.today().replace(day=max(1,date.today().day-2)).isoformat(),"RALPHS #0198",84.37,"demo-checking"),
        ("demo-tx-coffee",date.today().replace(day=max(1,date.today().day-1)).isoformat(),"COFFEE SHOP SANDBOX",6.45,"demo-card"),
        ("demo-tx-payroll",date.today().isoformat(),"DEMO PAYROLL DEPOSIT",2450.00,"demo-checking"),
    ]
    added=0
    with conn() as c:
        c.execute("INSERT OR IGNORE INTO connections(provider,environment,institution_name,item_id,status,created_at) VALUES(?,?,?,?,?,?)",("Plaid","sandbox-demo","First Platypus Bank (Demo)","hf-local-sandbox-demo","Active",now))
        connection_id=c.execute("SELECT id FROM connections WHERE item_id=?",("hf-local-sandbox-demo",)).fetchone()[0]
        for external_id,name,official,mask,typ,subtype,current,available in demo_accounts:
            c.execute("INSERT INTO linked_accounts(connection_id,provider_account_id,name,official_name,mask,type,subtype,current_balance,available_balance,last_sync) VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(provider_account_id) DO UPDATE SET current_balance=excluded.current_balance,available_balance=excluded.available_balance,last_sync=excluded.last_sync",(connection_id,external_id,name,official,mask,typ,subtype,current,available,now))
        names={x[0]:x[1] for x in demo_accounts}
        for external_id,tx_date,description,amount,account_id in demo_transactions:
            if c.execute("SELECT 1 FROM transaction_links WHERE provider=? AND external_id=?",("Plaid Sandbox Demo",external_id)).fetchone(): continue
            category=categorize(description); excluded=1
            fp=hashlib.sha256(f"plaid-sandbox-demo|{external_id}".encode()).hexdigest()
            cur=c.execute("INSERT OR IGNORE INTO transactions(tx_date,description,amount,category,account,excluded,source,fingerprint) VALUES(?,?,?,?,?,?,?,?)",(tx_date,description,amount,category,names[account_id],excluded,"Plaid Sandbox Demo",fp))
            if cur.rowcount:
                c.execute("INSERT INTO transaction_links(provider,external_id,transaction_id) VALUES(?,?,?)",("Plaid Sandbox Demo",external_id,cur.lastrowid)); added+=1
        c.execute("UPDATE connections SET cursor=?,last_sync=?,status='Active',error=NULL WHERE id=?",("demo-cursor-v1",now,connection_id))
    return added

def plaid_category(transaction):
    description=transaction.get("merchant_name") or transaction.get("name") or "Plaid transaction"
    if re.search(r"\bACORNS\b",description,re.I) and abs(abs(float(transaction.get("amount") or 0))-3.0)<0.01: return "Subscriptions"
    merchant_category=categorize(description)
    if merchant_category != "Other spending": return merchant_category
    primary=((transaction.get("personal_finance_category") or {}).get("primary") or "").upper()
    mapped={"INCOME":"Income","TRANSFER_IN":"Transfer","TRANSFER_OUT":"Transfer","LOAN_PAYMENTS":"Debt payment","BANK_FEES":"Fees & interest","FOOD_AND_DRINK":"Dining out","GENERAL_MERCHANDISE":"Shopping & household goods","HOME_IMPROVEMENT":"Shopping & household goods","RENT_AND_UTILITIES":"Utilities","TRANSPORTATION":"Transportation","ENTERTAINMENT":"Entertainment","MEDICAL":"Health"}.get(primary)
    return mapped or categorize(description)

def save_linked_accounts(connection_id,accounts,now):
    with conn() as c:
        for account in accounts:
            balances=account.get("balances") or {}
            c.execute("INSERT INTO linked_accounts(connection_id,provider_account_id,name,official_name,mask,type,subtype,current_balance,available_balance,currency,last_sync) VALUES(?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(provider_account_id) DO UPDATE SET name=excluded.name,official_name=excluded.official_name,mask=excluded.mask,type=excluded.type,subtype=excluded.subtype,current_balance=excluded.current_balance,available_balance=excluded.available_balance,currency=excluded.currency,last_sync=excluded.last_sync",(connection_id,account["account_id"],account.get("name") or "Linked account",account.get("official_name"),account.get("mask"),account.get("type"),account.get("subtype"),balances.get("current") or 0,balances.get("available"),balances.get("iso_currency_code") or "USD",now))

def sync_plaid_connection(connection_id):
    found=rows("SELECT * FROM connections WHERE id=? AND provider='Plaid'",(connection_id,))
    if not found: raise plaid.PlaidError("Connection was not found.","NOT_FOUND")
    item=found[0]
    if not item.get("access_token_enc"): raise plaid.PlaidError("This is only a local demonstration connection.","DEMO_CONNECTION")
    token=plaid.decrypt_token(item["access_token_enc"]); now=datetime.now(timezone.utc).isoformat()
    try:
        item_env=item.get("environment") or "sandbox"
        account_result=plaid.accounts_get(token,item_env); sync=plaid.transactions_sync(token,item.get("cursor"),item_env)
        save_linked_accounts(connection_id,account_result.get("accounts",[]),now)
        account_rules={x["provider_account_id"]:x for x in rows("SELECT provider_account_id,name,local_account,import_mode,cutover_date FROM linked_accounts WHERE connection_id=?",(connection_id,))}
        added=modified=removed=0
        with conn() as c:
            for transaction in sync["added"]:
                external_id=transaction["transaction_id"]; pending_id=transaction.get("pending_transaction_id")
                existing=c.execute("SELECT transaction_id FROM transaction_links WHERE provider='Plaid' AND external_id=?",(external_id,)).fetchone()
                if existing: continue
                if pending_id:
                    pending=c.execute("SELECT transaction_id FROM transaction_links WHERE provider='Plaid' AND external_id=?",(pending_id,)).fetchone()
                    if pending:
                        c.execute("DELETE FROM transaction_links WHERE provider='Plaid' AND external_id=?",(pending_id,)); c.execute("INSERT INTO transaction_links(provider,external_id,transaction_id) VALUES('Plaid',?,?)",(external_id,pending[0])); existing=pending
                description=transaction.get("merchant_name") or transaction.get("name") or "Plaid transaction"; category=plaid_category(transaction); tx_date=transaction.get("date") or date.today().isoformat(); rule=account_rules.get(transaction.get("account_id"),{}); account=rule.get("local_account") or rule.get("name") or "Plaid linked account"; active=rule.get("import_mode")=="active" and (not rule.get("cutover_date") or tx_date>rule["cutover_date"]); excluded=0 if item_env=="production" and active and category not in ("Transfer","Income","Debt payment","Investment","Reimbursement") else 1
                source=("Plaid Production" if active else "Plaid Production (review)") if item_env=="production" else "Plaid Sandbox"
                values=(tx_date,description,abs(float(transaction.get("amount") or 0)),category,account,excluded,source,hashlib.sha256(f"plaid|{item_env}|{external_id}".encode()).hexdigest())
                if existing:
                    c.execute("UPDATE transactions SET tx_date=?,description=?,amount=?,category=?,account=?,excluded=?,source=?,fingerprint=? WHERE id=?",(*values,existing[0])); modified+=1
                else:
                    cur=c.execute("INSERT OR IGNORE INTO transactions(tx_date,description,amount,category,account,excluded,source,fingerprint) VALUES(?,?,?,?,?,?,?,?)",values)
                    if cur.rowcount: c.execute("INSERT INTO transaction_links(provider,external_id,transaction_id) VALUES('Plaid',?,?)",(external_id,cur.lastrowid)); added+=cur.rowcount
            for transaction in sync["modified"]:
                link=c.execute("SELECT transaction_id FROM transaction_links WHERE provider='Plaid' AND external_id=?",(transaction["transaction_id"],)).fetchone()
                if link:
                    description=transaction.get("merchant_name") or transaction.get("name") or "Plaid transaction"; category=plaid_category(transaction); tx_date=transaction.get("date") or date.today().isoformat(); rule=account_rules.get(transaction.get("account_id"),{}); account=rule.get("local_account") or rule.get("name") or "Plaid linked account"; active=rule.get("import_mode")=="active" and (not rule.get("cutover_date") or tx_date>rule["cutover_date"]); excluded=0 if item_env=="production" and active and category not in ("Transfer","Income","Debt payment","Investment","Reimbursement") else 1
                    c.execute("UPDATE transactions SET tx_date=?,description=?,amount=?,category=?,account=?,excluded=? WHERE id=?",(tx_date,description,abs(float(transaction.get("amount") or 0)),category,account,excluded,link[0])); modified+=1
            for transaction in sync["removed"]:
                link=c.execute("SELECT transaction_id FROM transaction_links WHERE provider='Plaid' AND external_id=?",(transaction["transaction_id"],)).fetchone()
                if link: c.execute("UPDATE transactions SET excluded=1 WHERE id=?",(link[0],)); c.execute("UPDATE transaction_links SET removed=1 WHERE provider='Plaid' AND external_id=?",(transaction["transaction_id"],)); removed+=1
            c.execute("UPDATE connections SET cursor=?,last_sync=?,status='Active',error=NULL WHERE id=?",(sync["next_cursor"],now,connection_id))
        register_matched=reconcile_register()
        return {"added":added,"modified":modified,"removed":removed,"register_matched":register_matched}
    except plaid.PlaidError as exc:
        with conn() as c: c.execute("UPDATE connections SET status='Error',error=? WHERE id=?",(f"{exc.error_code}: {str(exc)}"[:300],connection_id))
        raise

def automatic_sync_loop():
    while True:
        time.sleep(AUTO_SYNC_HOURS*3600)
        for item in rows("SELECT id,environment FROM connections WHERE provider='Plaid' AND status IN ('Active','Error') AND access_token_enc IS NOT NULL"):
            try:
                result=sync_plaid_connection(item["id"]); print(f"Automatic Plaid {item['environment']} sync {item['id']}: {result}",flush=True)
            except Exception as exc: print(f"Automatic Plaid {item['environment']} sync {item['id']} failed: {type(exc).__name__}",flush=True)

def next_payday(today=None):
    today=today or date.today()
    if today.day < 21: return today.replace(day=21).isoformat()
    year=today.year+(1 if today.month==12 else 0); month=1 if today.month==12 else today.month+1
    return date(year,month,7).isoformat()

def categorize(desc):
    s=desc.upper()
    # Credit-card statement payments move money toward debt; they are not
    # purchases and must never inflate monthly lifestyle spending.
    if re.search(r"^\s*PAYMENT\s*-?\s*THANK YOU\s*$",s):
        return "Debt payment"
    # Ralphs is an unambiguous grocery merchant. Keep a stale or accidental
    # learned rule from overriding it in reports and future imports.
    if re.search(r"\bRALPHS\b",s):
        return "Gas" if "FUEL" in s else "Groceries"
    # A learned rule for a Costco fuel charge must not turn ordinary Costco
    # warehouse purchases into fuel spending.
    if re.search(r"\bCOSTCO\b",s):
        return "Gas" if "GAS" in s or "FUEL" in s else "Shopping & household goods"
    # These merchants contain words that collide with broader rules below.
    # Resolve them before consulting learned or generic patterns.
    if re.search(r"\bUBER\s*EATS\b",s):
        return "Dining out"
    if re.search(r"\bHIGH PARK DELI\b",s):
        return "Dining out"
    if re.search(r"\bAMAZON PRIME\b",s):
        return "Subscriptions"
    learned = MERCHANT_RULE_CACHE.get(merchant_key(desc))
    if learned in CATEGORIES: return learned
    rules=[("Reimbursement",r"ZELLE.*KRISTIAN BLAKE|KRISTIAN BLAKE.*ZELLE|STATEMENT CREDIT"),("Insurance",r"USAA P&C BILLPYMNT|USAA P&C.*PAYMENT"),("Utilities",r"CONSUMER CELLULAR"),("Housing",r"FS PAY-HOA|HOA ASSES"),("Alcohol",r"BEVERAGES?\s*&\s*MORE|\bBEVMO\b|\bLIQUOR\b"),("Bar",r"THE HEARTH HOUSE|\bHEARTH HOUSE\b|SHOUT HOUSE|WONG'?S DRAGON ROOM|PUB THIRTY TWO"),("Camping & lodging",r"RESERVECALIFORNIA|CAMPGROUND|CAMPSITE|STATE PARK RESERVATION|HOTEL|MOTEL|INN\b|LODGING"),("Entertainment",r"FANDANGO|PLAYSTATION|SONY PLAYSTATION|\bREGAL\b|SEA\s*WORLD|\bHOB CLUB\b|HOUSE OF BLUES|THE PHANTOM OF|NORTH ISLAND CREDIT|HEARST CASTLE|MOUNTAIN PARKS FOU|PFEIFFER BIG SUR|TICKETMASTER|MUSIC BOX|MAGNOLIA"),("Health",r"THE JOINT CORP|\bJOINT CORP\b"),("Returned payment",r"RETURNED.*(?:PAY|ACH)"),("Fees & interest",r"\bOD FEE\b|OVERDRAFT FEE|NSF FEE|ATM FEE|SAVINGS FEE|INTEREST CHARGE|LATE FEE|PAST DUE FEE"),("Software",r"\bOPENAI\b|PLEX.*LIFETIME|TURBOTAX|PAYPRO|DAVE S PEREY"),("Subscriptions",r"NETFLIX|AUDIBLE|PARAMOUNT|PEACOCK|GAMEFLY|DVDINBOX|INCOGNI|OPTERY|TRUECALLER|GOOGLE FAMILY SHARED|FOX NATION|FIREWALLA"),("Transportation",r"\bPRONTO\b|\bUBER\b|\bLYFT\b|RENTAL CAR|TAXI"),("Income",r"PAYROLL|ADP|DEPOSIT"),("Transfer",r"TRANSFER|ZELLE"),("Debt payment",r"CCPYMT|CARD PAYMENT|PENNYMAC|REACH FINANCIAL|MISSION LANE"),("Investment",r"ACORNS"),("Automotive repair",r"AUTO\s*REPAIR|AUTO\s*BODY|AUTOBODY|AUTOZONE|NAPA AUTO|OIL\s*CHANGE|TIRE|MECHANIC|MUFFLER|TRANSMISSION|BEARING"),("Automotive general",r"CAR\s*WASH|AUTO\s*WASH|AUTO\s*SPA|DETAILING|DMV|DEPARTMENT OF MOTOR VEHICLES|VEHICLE\s*REGISTRATION|\bPARKING\b|\bPARKMOBILE\b|MONTEREY.*LOT|AIRPORT PARKING"),("Tolls",r"\bTOLL(?:S|\s+ROADS?)?\b|FASTRAK"),("Gas",r"COSTCO GAS|RALPHS FUEL|SUPER STAR GAS|G&M OIL|\bGAS\b|\bFUEL\b|\bSHELL\b|\bCHEVRON\b|\bARCO\b|\bCIRCLE K\b|7-ELEVEN"),("Groceries",r"RALPHS|ALDI|COSTCO|WAL.?MART|TRADER JOE|ALBERTSON|FRAZIER|SAFEWAY|\bVONS\b"),("Dining out",r"VENMO.*KATHLEEN KASAR|STARBUCKS|DOMINO|TACO|DENNY|RESTAURANT|GRUBHUB|DOORDASH|A\s*&\s*W MARKET|HABIT BURGER|HOOLEYS|DEL'?S HIDEOUT|DOMENICO|BAGELS?\s*&\s*BREW|LITTLE FERRY SUSHI|\bDELI\b"),("Household & home improvement",r"HOME DEPOT|HARBOR FREIGHT|LOWE'?S|ACE HARDWARE|MIRAMAR LANDFILL|CITY FARMERS"),("Shopping & household goods",r"AMAZON|TARGET|GOODWILL|TRUE LEGACY|SHE SELLS SEASHELLS|HARBOR HOUSE GIFTS"),("Pets",r"CHEWY|PETCO|PETSMART")]
    return next((cat for cat,pat in rules if re.search(pat,s)),"Other spending")

def map_usaa_category(raw, desc=""):
    """Translate USAA's export categories into the app's stable categories."""
    c=(raw or "").strip().lower()
    groups={
        "Groceries":{"groceries"},
        "Health":{"pharmacy","doctor"},
        "Household & home improvement":{"furnishings","home","laundry","lawn & garden","home improvement"},
        "Dining out":{"fast food","food & dining","restaurants","coffee shops"},
        "Automotive repair":{"service & parts"},
        "Automotive general":{"parking"},
        "Gas":{"gas"},
        "Transportation":{"rental car & taxi"},
        "Software":{"electronics & software"},
        "Shopping & household goods":{"shopping","clothing","shipping","hobbies"},
        "Insurance":{"insurance"}, "Pets":{"pet food & supplies"},
        "Subscriptions":{"television","music","entertainment"},
        "Personal transfers":{"cash","gifts & donations","charity"},
        "Debt payment":{"credit card payment"}, "Income":{"paycheck","income"}, "Reimbursement":{"reimbursement"},
        "Investment":{"investments"}, "Transfer":{"transfer"},
        "Utilities":{"utilities","mobile phone"},
        "Alcohol":{"alcohol & bars"},
        "Other spending":{"service fee","fees & charges","atm fee","travel","business services","movies & dvds","amusement","hair","financial","taxes","uncategorized","category pending"},
    }
    if c == "auto & transport":
        inferred = categorize(desc)
        return inferred if inferred != "Other spending" else "Automotive general"
    return next((ours for ours, theirs in groups.items() if c in theirs), categorize(desc))

def map_nfcu_category(raw, desc=""):
    c=(raw or "").strip().lower()
    groups={
        "Transfer":{"transfers"},
        "Debt payment":{"credit card payments","loans","mortgages"},
        "Income":{"paychecks/salary","deposits"},
        "Investment":{"investment income"},
        "Utilities":{"utilities","cable/satellite services","telephone services"},
        "Insurance":{"insurance"},
        "Housing":{"taxes"},
        "Household & home improvement":{"home maintenance","home improvement"},
        "Groceries":{"groceries"},
        "Personal transfers":{"atm/cash withdrawals"},
        "Other spending":{"other expenses","service charges/fees"},
    }
    return next((ours for ours, theirs in groups.items() if c in theirs), categorize(desc))

def map_capital_one_category(raw, desc=""):
    c=(raw or "").strip().lower()
    groups={
        "Debt payment":{"payment/credit"},
        "Fees & interest":{"fee/interest charge"},
        "Shopping & household goods":{"merchandise"},
        "Subscriptions":{"phone/cable","entertainment","other services"},
        "Dining out":{"dining"},
        "Gas":{"gas/automotive"},
        "Other spending":{"other"},
    }
    return next((ours for ours, theirs in groups.items() if c in theirs), categorize(desc))

def parse_money(v):
    if v is None: return 0.0
    s=str(v).strip().replace("$","").replace(",","")
    neg=s.startswith("(") and s.endswith(")")
    s=s.strip("()")
    try: n=float(s or 0)
    except ValueError: n=0
    return -n if neg else n

def subscription_name(description):
    """Return a stable, readable merchant name for a subscription candidate."""
    s=" ".join((description or "").strip().split()); u=s.upper()
    known=(("ACORNS","Acorns"),("FIREWALLA","Firewalla MSP Board"),("NETFLIX","Netflix"),("AUDIBLE","Audible"),("DISNEY","Disney+ via Roku"),("PEACOCK","Peacock via Roku"),("TRUECALLER","Google Truecaller"),("FAMILY SHARED","Google Family Shared"),("GAMEFLY","GameFly"),("DVDINBOX","DVDInbox.com"),("PARAMOUNT","Paramount+"))
    for token,name in known:
        if token in u: return name
    return (re.sub(r"[*#][A-Z0-9]+$","",s).strip(" *-")[:80] or "Unknown subscription")

def record_subscription_candidates(parsed):
    candidates={}
    for tx_date,desc,amount,category,account,excluded,source in parsed:
        if category=="Subscriptions":
            name=subscription_name(desc); previous=candidates.get(name)
            if previous is None or tx_date>previous[2]: candidates[name]=(amount,account,tx_date)
    if not candidates: return
    with conn() as c:
        for name,(amount,account,last_seen) in candidates.items():
            existing=c.execute("SELECT id FROM subscriptions WHERE name=?",(name,)).fetchone()
            if existing: c.execute("UPDATE subscriptions SET amount=?,paid_from=?,last_seen=? WHERE id=?",(amount,account,last_seen,existing["id"]))
            else: c.execute("INSERT INTO subscriptions(name,amount,frequency,paid_from,still_needed,cancellation_status,last_seen,notes) VALUES(?,?,?,?,?,?,?,?)",(name,amount,"Monthly",account,"Review","None",last_seen,"New subscription candidate detected during import; confirm whether it is recurring and still needed."))

def parse_csv_data(data, account, filename):
    text=data.decode("utf-8-sig",errors="replace")
    reader=csv.DictReader(io.StringIO(text)); out=[]
    for r in reader:
        norm={re.sub(r"[^a-z]","",k.lower()):v for k,v in r.items() if k}
        if norm.get("status") and norm["status"].strip().lower() != "posted": continue
        raw_date=next((norm.get(k) for k in ("date","postingdate","transactiondate","posteddate") if norm.get(k)),None)
        desc=next((norm.get(k) for k in ("description","memo","name","payee") if norm.get(k)),"")
        if not raw_date or not desc: continue
        txd=None
        for fmt in ("%m/%d/%Y","%m/%d/%y","%Y-%m-%d"):
            try: txd=datetime.strptime(raw_date.strip(),fmt).date().isoformat(); break
            except ValueError: pass
        if not txd: continue
        if norm.get("amount") not in (None,""):
            amount=parse_money(norm["amount"])
            indicator=norm.get("creditdebitindicator","").strip().lower()
            if indicator=="debit": amount=-abs(amount)
            elif indicator=="credit": amount=abs(amount)
        else: amount=parse_money(norm.get("credit"))-parse_money(norm.get("debit"))
        supplied=norm.get("category","")
        if norm.get("cardno") is not None:
            category=map_capital_one_category(supplied,desc)
        elif norm.get("creditdebitindicator"):
            category=map_nfcu_category(supplied,desc)
        else:
            category=map_usaa_category(supplied,desc) if supplied else categorize(desc)
        merchant_category=categorize(desc)
        if merchant_category != "Other spending": category=merchant_category
        if re.search(r"\bACORNS\b",desc,re.I) and abs(abs(amount)-3.0)<0.01: category="Subscriptions"
        # Positive USAA amounts are deposits. Transfers, income, investments, and
        # debt payments are excluded from lifestyle-spending totals by default.
        excluded=1 if amount > 0 or category in ("Transfer","Income","Debt payment","Investment","Returned payment") else 0
        out.append((txd,desc.strip(),abs(amount),category,account,excluded,filename))
    returned={(x[0],round(x[2],2),x[4]) for x in out if x[3]=="Returned payment"}
    out=[(txd,desc,amount,"Returned payment",acct,1,source) if category=="Debt payment" and (txd,round(amount,2),acct) in returned else (txd,desc,amount,category,acct,excluded,source) for txd,desc,amount,category,acct,excluded,source in out]
    return out

def parse_ofx(data, account, filename):
    text=data.decode("utf-8",errors="replace"); out=[]
    for block in re.findall(r"<STMTTRN>(.*?)(?=<STMTTRN>|</BANKTRANLIST>|$)",text,re.I|re.S):
        def tag(name):
            m=re.search(fr"<{name}>([^<\r\n]+)",block,re.I); return m.group(1).strip() if m else ""
        ds=tag("DTPOSTED")[:8]; desc=(tag("NAME")+" "+tag("MEMO")).strip(); amt=parse_money(tag("TRNAMT"))
        if len(ds)==8 and desc: out.append((f"{ds[:4]}-{ds[4:6]}-{ds[6:8]}",desc,abs(amt),categorize(desc),account,1 if categorize(desc) in ("Transfer","Income","Debt payment","Returned payment") else 0,filename))
    return out

class Handler(SimpleHTTPRequestHandler):
    enrollment_secret = None
    login_attempts = {}
    def end_headers(self):
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Permissions-Policy", "camera=(), microphone=(), geolocation=(), payment=()")
        if urlparse(self.path).path.endswith((".html", ".js", ".css")) or urlparse(self.path).path == "/":
            self.send_header("Cache-Control", "no-store, max-age=0")
            self.send_header("Pragma", "no-cache")
            self.send_header("Expires", "0")
        super().end_headers()
    def translate_path(self,path):
        static_root=STATIC.resolve()
        requested=(static_root/unquote(urlparse(path).path).lstrip("/")).resolve()
        try: requested.relative_to(static_root)
        except ValueError: return str(static_root/"__not_found__")
        return str(requested)
    def log_message(self,fmt,*args): print(f"[{self.log_date_time_string()}] {fmt%args}")
    def send_json(self,obj,status=200):
        body=json.dumps(obj,default=str).encode(); self.send_response(status); self.send_header("Content-Type","application/json"); self.send_header("Content-Length",str(len(body))); self.end_headers(); self.wfile.write(body)
    def body(self):
        try: n=int(self.headers.get("Content-Length","0"))
        except ValueError: raise RequestBodyError("Invalid request length.")
        if n<0: raise RequestBodyError("Invalid request length.")
        if n>MAX_JSON_BODY_BYTES: raise RequestBodyError("Request is too large.",413)
        try: return json.loads(self.rfile.read(n) or b"{}")
        except (UnicodeDecodeError,json.JSONDecodeError): raise RequestBodyError("Request must contain valid JSON.")
    def cookie(self,name):
        for part in self.headers.get("Cookie","").split(";"):
            k,sep,v=part.strip().partition("=")
            if sep and k==name: return v
        return None
    def session(self):
        token=self.cookie("HFSESSION")
        if not token: return None
        found=rows("SELECT sessions.*,users.username FROM sessions JOIN users ON users.id=sessions.user_id WHERE token_hash=? AND expires_at>? AND users.active=1",(auth.token_hash(token),datetime.now(timezone.utc).isoformat()))
        return found[0] if found else None
    def configured(self): return bool(rows("SELECT 1 FROM users WHERE active=1 LIMIT 1"))
    def set_session(self,user_id):
        token,digest,csrf,expires=auth.new_session()
        with conn() as c:
            c.execute("DELETE FROM sessions WHERE expires_at<=?",(datetime.now(timezone.utc).isoformat(),))
            c.execute("INSERT INTO sessions(user_id,token_hash,csrf_token,expires_at,created_at) VALUES(?,?,?,?,?)",(user_id,digest,csrf,expires,datetime.now(timezone.utc).isoformat()))
        secure="; Secure" if os.environ.get("HF_SECURE_COOKIE","false").lower()=="true" else ""
        self.send_header("Set-Cookie",f"HFSESSION={token}; HttpOnly; SameSite=Strict; Path=/; Max-Age={auth.SESSION_HOURS*3600}{secure}")
    def redirect(self,path):
        self.send_response(302); self.send_header("Location",path); self.send_header("Content-Length","0"); self.end_headers()
    def do_GET(self):
        p=urlparse(self.path)
        public=("/login.html","/setup.html","/style.css","/badges.css","/favicon.svg","/fine-nance-login.png")
        if not p.path.startswith("/api/"):
            if p.path in public: return super().do_GET()
            if not self.session(): return self.redirect("/login.html" if self.configured() else "/setup.html")
            return super().do_GET()
        if p.path=="/api/auth/status":
            s=self.session(); return self.send_json({"configured":self.configured(),"authenticated":bool(s),"username":s["username"] if s else None})
        if p.path=="/api/auth/enrollment":
            if self.configured(): return self.send_json({"error":"Already configured"},403)
            Handler.enrollment_secret=auth.new_totp_secret()
            uri=f"otpauth://totp/Fine%20Nance:administrator?secret={Handler.enrollment_secret}&issuer=Fine%20Nance"
            return self.send_json({"secret":Handler.enrollment_secret,"qr":auth.qr_data_uri(uri)})
        session=self.session()
        if not session: return self.send_json({"error":"Authentication required"},401)
        if p.path=="/api/dashboard":
            bills=rows("SELECT * FROM bills WHERE active=1 ORDER BY COALESCE(due_day,99),name")
            debts=rows("SELECT * FROM debts ORDER BY balance DESC")
            inv=rows("SELECT * FROM investments ORDER BY name")
            accounts=rows("SELECT * FROM accounts WHERE active=1 ORDER BY name")
            one_time=rows("SELECT * FROM one_time_bills ORDER BY CASE WHEN status='Paid' THEN 1 ELSE 0 END,due_date,name")
            documents=rows("SELECT d.*,o.status AS bill_status FROM documents d LEFT JOIN one_time_bills o ON o.id=d.one_time_bill_id WHERE d.active=1 ORDER BY d.uploaded_at DESC,d.id DESC")
            subscriptions=rows("SELECT * FROM subscriptions WHERE active=1 ORDER BY CASE WHEN cancellation_status='Reminder' THEN 0 WHEN still_needed='Review' THEN 1 ELSE 2 END,name")
            trips=rows("SELECT * FROM trips WHERE active=1 ORDER BY start_date DESC,id DESC")
            trip_transactions=rows("SELECT trip_id,transaction_id FROM trip_transactions ORDER BY trip_id,transaction_id")
            audit=audit_findings()
            connections=rows("SELECT id,provider,environment,institution_id,institution_name,item_id,status,cursor,last_sync,error,created_at FROM connections ORDER BY created_at DESC")
            linked_accounts=rows("SELECT * FROM linked_accounts ORDER BY name")
            register_entries=rows("""SELECT r.*,t.tx_date AS matched_tx_date,t.description AS matched_tx_description
                FROM register_entries r LEFT JOIN transactions t ON t.id=r.matched_transaction_id
                ORDER BY CASE r.status WHEN 'Pending' THEN 0 WHEN 'Matched' THEN 1 ELSE 2 END,r.entry_date DESC,r.id DESC""")
            register_accounts=register_account_summaries()
            email_config=email_settings()
            notification_history=rows("SELECT id,notification_type,recipient,subject,status,detail,created_at FROM notification_history ORDER BY id DESC LIMIT 50")
            tx=rows("SELECT * FROM transactions ORDER BY tx_date DESC,id DESC")
            buffer=float(rows("SELECT value FROM settings WHERE key='bill_buffer'")[0]["value"])
            nfcu=sum(b["planned"] for b in bills if b["paid_from"]=="NFCU Bill Pay")
            card=sum(b["planned"] for b in bills if b["paid_from"]!="NFCU Bill Pay")
            nonspending=tuple(sorted(NON_SPENDING_CATEGORIES))
            category_slots=",".join("?" for _ in nonspending)
            cat_rows=rows(f"SELECT category, SUM(amount) total FROM transactions WHERE excluded=0 AND category NOT IN ({category_slots}) GROUP BY category",nonspending)
            cats={r["category"]:r["total"] for r in cat_rows}
            period=rows("SELECT MIN(tx_date) start, MAX(tx_date) end, COUNT(*) count FROM transactions")[0]
            month_rows=rows(f"SELECT SUBSTR(tx_date,1,7) month, category, SUM(amount) total, COUNT(*) count FROM transactions WHERE excluded=0 AND category NOT IN ({category_slots}) GROUP BY SUBSTR(tx_date,1,7),category ORDER BY month",nonspending)
            monthly={}
            for r in month_rows:
                m=monthly.setdefault(r["month"],{"categories":{},"total":0,"count":0})
                m["categories"][r["category"]]=r["total"]; m["total"]+=r["total"]; m["count"]+=r["count"]
            latest_pay=rows("SELECT MAX(tx_date) pay_date FROM transactions WHERE category='Income' AND UPPER(description) LIKE '%ZEPHYR%'")[0]["pay_date"]
            pay_rows=rows("SELECT account,SUM(amount) amount FROM transactions WHERE tx_date=? AND category='Income' AND UPPER(description) LIKE '%ZEPHYR%' GROUP BY account",(latest_pay,)) if latest_pay else []
            va_row=rows("SELECT tx_date,amount FROM transactions WHERE account='NFCU Bill Pay Savings' AND category='Income' AND UPPER(description) LIKE '%VETERAN AFFAIRS%' ORDER BY tx_date DESC LIMIT 1")
            va_setting=rows("SELECT value FROM settings WHERE key='va_monthly_income'")
            va_income=float(va_setting[0]["value"]) if va_setting else (va_row[0]["amount"] if va_row else 0)
            savings_setting=rows("SELECT value FROM settings WHERE key='usaa_savings_per_paycheck'")
            savings_per_check=float(savings_setting[0]["value"]) if savings_setting else 0
            cc_monthly=sum(b["planned"] for b in bills if b["category"]=="Credit Card" and b["paid_from"]=="NFCU Bill Pay")
            paycheck={"date":latest_pay,"accounts":pay_rows,"total":sum(x["amount"] for x in pay_rows)+savings_per_check,"frequency":"Twice monthly","payDays":[7,21],"nextPayday":next_payday(),"checksPerMonth":2,"usaaSavingsPerCheck":savings_per_check,"otherMonthlyNfcuIncome":va_income,"otherIncomeLabel":"permanent monthly VA payment","otherIncomePermanent":True,"otherIncomeAsOf":va_row[0]["tx_date"] if va_row else None,"creditCardMonthly":cc_monthly,"regularBillsMonthly":nfcu-cc_monthly}
            return self.send_json({"csrf":session["csrf_token"],"bills":bills,"oneTimeBills":one_time,"documents":documents,"documentFolders":document_folders(),"subscriptions":subscriptions,"trips":trips,"tripTransactions":trip_transactions,"audit":audit,"paycheck":paycheck,"debts":debts,"investments":inv,"accounts":accounts,"connections":connections,"linkedAccounts":linked_accounts,"registerEntries":register_entries,"registerAccounts":register_accounts,"emailSettings":email_config,"notificationHistory":notification_history,"integration":{"mode":PLAID_MODE,"autoSyncHours":AUTO_SYNC_HOURS,"sandboxConfigured":plaid.configured("sandbox"),"realSandboxConfigured":plaid.configured("sandbox"),"productionConfigured":plaid.configured("production"),"productionAllowed":ALLOW_PRODUCTION},"transactions":tx,"spendingPeriod":period,"monthly":monthly,"summary":{"nfcu":nfcu,"card":card,"total":nfcu+card,"buffer":buffer,"nfcuTarget":nfcu+buffer,"oneTimeDue":sum(x["amount"] for x in one_time if x["status"]!='Paid'),"cash":sum(a["balance"] for a in accounts),"debt":sum(d["balance"] for d in debts),"spending":sum(cats.values())},"categories":cats,"categoryOptions":CATEGORIES})
        if p.path=="/api/documents/file":
            try: document_id=int(parse_qs(p.query).get("id",[""])[0])
            except (TypeError,ValueError): return self.send_json({"error":"Invalid document."},400)
            found=rows("SELECT * FROM documents WHERE id=? AND active=1",(document_id,))
            if not found: return self.send_json({"error":"Document not found."},404)
            document=found[0]; file_path=DOCUMENTS/document["stored_name"]
            try:
                if file_path.resolve().parent!=DOCUMENTS.resolve() or not file_path.is_file(): raise FileNotFoundError
                body=file_path.read_bytes()
            except (OSError,FileNotFoundError): return self.send_json({"error":"Stored file is unavailable."},404)
            safe_name=re.sub(r"[^A-Za-z0-9._ -]","_",document["original_name"])[:180] or "document"
            self.send_response(200); self.send_header("Content-Type",document["mime_type"]); self.send_header("Content-Disposition",f"inline; filename*=UTF-8''{quote(safe_name)}"); self.send_header("Content-Length",str(len(body))); self.send_header("Cache-Control","private, no-store"); self.send_header("X-Content-Type-Options","nosniff"); self.end_headers(); return self.wfile.write(body)
        if p.path=="/api/backup":
            payload={t:rows(f"SELECT * FROM {t}") for t in ("accounts","bills","one_time_bills","documents","subscriptions","debts","transactions","register_entries","investments","trips","trip_transactions","audit_reviews","settings")}
            body=json.dumps(payload,indent=2).encode(); self.send_response(200); self.send_header("Content-Type","application/json"); self.send_header("Content-Disposition",f'attachment; filename="harrington-finance-{date.today()}.json"'); self.send_header("Content-Length",str(len(body))); self.end_headers(); return self.wfile.write(body)
        if p.path=="/api/app-update":
            try: return self.send_json(fetch_update_manifest())
            except Exception as error: return self.send_json({"configured":bool(UPDATE_MANIFEST_URL),"current_version":APP_VERSION,"update_available":False,"error":str(error)},502)
        self.send_json({"error":"Not found"},404)
    def do_HEAD(self):
        p=urlparse(self.path)
        public=("/login.html","/setup.html","/style.css","/badges.css","/favicon.svg","/fine-nance-login.png")
        if not p.path.startswith("/api/") and p.path not in public and not self.session():
            return self.redirect("/login.html" if self.configured() else "/setup.html")
        return super().do_HEAD()
    def do_POST(self):
        try: return self._do_POST()
        except RequestBodyError as error: return self.send_json({"error":str(error)},error.status)

    def _do_POST(self):
        p=urlparse(self.path).path
        if p=="/api/auth/setup":
            if self.configured(): return self.send_json({"error":"Already configured"},403)
            d=self.body(); username=str(d.get("username","")).strip().lower(); password=str(d.get("password","")).strip(); secret=str(d.get("secret","")).strip()
            if not re.fullmatch(r"[a-z][a-z0-9_-]{2,31}",username): return self.send_json({"error":"Use a 3–32 character lowercase username."},400)
            if len(password)<14: return self.send_json({"error":"Password must be at least 14 characters."},400)
            if secret!=Handler.enrollment_secret or not auth.totp_ok(secret,d.get("code")): return self.send_json({"error":"Authenticator code was not accepted."},400)
            try: encoded_password=auth.password_hash(password)
            except Exception:
                return self.send_json({"error":"Secure password processing failed. Please try again after the server is updated."},500)
            with conn() as c:
                cur=c.execute("INSERT INTO users(username,password_hash,totp_secret,created_at) VALUES(?,?,?,?)",(username,encoded_password,secret,datetime.now(timezone.utc).isoformat())); user_id=cur.lastrowid
            self.send_response(201); self.set_session(user_id); body=b'{"ok":true}'; self.send_header("Content-Type","application/json"); self.send_header("Content-Length",str(len(body))); self.end_headers(); return self.wfile.write(body)
        if p=="/api/auth/login":
            d=self.body(); ip=self.client_address[0]; now=time.time(); attempts=[x for x in Handler.login_attempts.get(ip,[]) if now-x<300]
            if len(attempts)>=5: return self.send_json({"error":"Sign-in temporarily unavailable"},429)
            found=rows("SELECT * FROM users WHERE username=? AND active=1",(str(d.get("username","")).strip().lower(),)); user=found[0] if found else None
            if not user or not auth.password_ok(str(d.get("password","")),user["password_hash"]) or not auth.totp_ok(user["totp_secret"],d.get("code")):
                Handler.login_attempts[ip]=attempts+[now]; time.sleep(.4); return self.send_json({"error":"Sign-in failed"},401)
            Handler.login_attempts.pop(ip,None); self.send_response(200); self.set_session(user["id"]); body=b'{"ok":true}'; self.send_header("Content-Type","application/json"); self.send_header("Content-Length",str(len(body))); self.end_headers(); return self.wfile.write(body)
        session=self.session()
        if not session: return self.send_json({"error":"Authentication required"},401)
        if not hmac.compare_digest(self.headers.get("X-CSRF-Token",""),session["csrf_token"]): return self.send_json({"error":"CSRF validation failed"},403)
        if p=="/api/auth/logout":
            with conn() as c: c.execute("DELETE FROM sessions WHERE id=?",(session["id"],))
            self.send_response(200); self.send_header("Set-Cookie","HFSESSION=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0"); self.send_header("Content-Length","0"); self.end_headers(); return
        if p=="/api/app-update/install":
            if os.name!="nt": return self.send_json({"error":"Automatic installation is available on the standalone Windows edition only."},400)
            try:
                manifest=fetch_update_manifest()
                if not manifest.get("update_available"): return self.send_json({"error":"Fine Nance is already up to date."},409)
                request=urllib.request.Request(manifest["package_url"],headers={"User-Agent":"Fine-Nance-Updater/1.0"}); package=Path(tempfile.gettempdir())/f"FineNance-{manifest['latest_version']}-{uuid.uuid4().hex}.zip"; digest=hashlib.sha256()
                with urllib.request.urlopen(request,timeout=60) as response,package.open("wb") as output:
                    while chunk:=response.read(1024*1024): digest.update(chunk); output.write(chunk)
                if not hmac.compare_digest(digest.hexdigest(),manifest["sha256"]): package.unlink(missing_ok=True); return self.send_json({"error":"The downloaded update failed its security check."},400)
                runner=ROOT/"update_runner.ps1"
                if not runner.exists(): package.unlink(missing_ok=True); return self.send_json({"error":"The updater component is missing."},500)
                subprocess.Popen(["powershell.exe","-NoProfile","-ExecutionPolicy","Bypass","-File",str(runner),"-PackagePath",str(package),"-ExpectedSha256",manifest["sha256"],"-ServerPid",str(os.getpid()),"-InstallRoot",str(ROOT.parent)],creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0),close_fds=True)
                return self.send_json({"ok":True,"message":"Update verified. Fine Nance will restart automatically."})
            except Exception as error: return self.send_json({"error":f"Update could not be installed: {error}"},500)
        if p=="/api/email/settings":
            d=self.body()
            sender=str(d.get("sender","")).strip(); recipient=str(d.get("recipient","")).strip(); host=str(d.get("host","smtp.gmail.com")).strip()
            if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+",sender) or not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+",recipient): return self.send_json({"error":"Enter valid sender and recipient email addresses."},400)
            try:
                port=int(d.get("port",587)); days=int(d.get("reminder_days",7))
                if port not in (465,587) or not 1<=days<=30: raise ValueError
                save_email_settings({"enabled":bool(d.get("enabled")),"sender":sender,"recipient":recipient,"host":host,"port":port,"reminder_days":days},str(d.get("password","")).replace(" ",""))
            except ValueError as exc: return self.send_json({"error":str(exc) or "Use SMTP port 465 or 587 and 1–30 reminder days."},400)
            return self.send_json({"ok":True,"settings":email_settings()})
        if p=="/api/email/test":
            try: send_email("Fine Nance test email","Success! Fine Nance can securely send email through your configured account.\n\nBill reminders will be sent only when email alerts are enabled.","Test")
            except (ValueError,smtplib.SMTPException,OSError) as exc: return self.send_json({"error":f"Test email failed: {exc}"},400)
            return self.send_json({"ok":True,"message":"Test email sent."})
        if p=="/api/email/reminders":
            try: sent=send_due_bill_reminders(force=True)
            except (ValueError,smtplib.SMTPException,OSError) as exc: return self.send_json({"error":f"Reminder check failed: {exc}"},400)
            return self.send_json({"ok":True,"message":"Upcoming-bill reminder sent." if sent else "No bills are due within the configured reminder window."})
        if p=="/api/connections/demo-sync":
            added=demo_sandbox_sync()
            return self.send_json({"ok":True,"added":added,"message":"Sandbox sync complete. No real institution was contacted."})
        if p=="/api/plaid/link-token":
            if PLAID_MODE=="production" and not ALLOW_PRODUCTION: return self.send_json({"error":"Production access has not been explicitly enabled."},403)
            try:
                result=plaid.create_link_token("hf-user-"+hashlib.sha256(str(session["user_id"]).encode()).hexdigest()[:20],PLAID_MODE)
                return self.send_json({"link_token":result["link_token"],"expiration":result.get("expiration")})
            except plaid.PlaidError as exc: return self.send_json({"error":str(exc),"code":exc.error_code,"request_id":exc.request_id},400)
        if p=="/api/plaid/exchange":
            if PLAID_MODE=="production" and not ALLOW_PRODUCTION: return self.send_json({"error":"Production access has not been explicitly enabled."},403)
            d=self.body(); public_token=str(d.get("public_token",'')); metadata=d.get("metadata") or {}; institution=metadata.get("institution") or {}
            if not public_token: return self.send_json({"error":"Plaid did not return a public token."},400)
            try:
                exchanged=plaid.exchange_public_token(public_token,PLAID_MODE); token=exchanged["access_token"]; item_id=exchanged["item_id"]; now=datetime.now(timezone.utc).isoformat(); name=str(institution.get("name") or f"Plaid {PLAID_MODE.title()} institution")[:120]; institution_id=str(institution.get("institution_id") or "")[:80]
                with conn() as c:
                    c.execute("INSERT INTO connections(provider,environment,institution_id,institution_name,item_id,access_token_enc,status,created_at) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(item_id) DO UPDATE SET institution_id=excluded.institution_id,institution_name=excluded.institution_name,access_token_enc=excluded.access_token_enc,status='Active',error=NULL",("Plaid",PLAID_MODE,institution_id,name,item_id,plaid.encrypt_token(token),"Active",now))
                    connection_id=c.execute("SELECT id FROM connections WHERE item_id=?",(item_id,)).fetchone()[0]
                save_linked_accounts(connection_id,plaid.accounts_get(token,PLAID_MODE).get("accounts",[]),now)
                sync_result=sync_plaid_connection(connection_id)
                return self.send_json({"ok":True,"connection_id":connection_id,"sync":sync_result},201)
            except plaid.PlaidError as exc: return self.send_json({"error":str(exc),"code":exc.error_code,"request_id":exc.request_id},400)
        if p=="/api/plaid/sync":
            d=self.body()
            try: return self.send_json({"ok":True,**sync_plaid_connection(int(d.get("connection_id",0)))})
            except (ValueError,TypeError): return self.send_json({"error":"Invalid connection."},400)
            except plaid.PlaidError as exc: return self.send_json({"error":str(exc),"code":exc.error_code,"request_id":exc.request_id},400)
        if p=="/api/trips":
            d=self.body(); name=str(d.get("name","")).strip(); start=str(d.get("start_date","")).strip(); end=str(d.get("end_date","")).strip()
            if not name or not start or not end: return self.send_json({"error":"Trip name, start date, and end date are required."},400)
            try:
                if date.fromisoformat(end)<date.fromisoformat(start): raise ValueError
            except ValueError: return self.send_json({"error":"Enter a valid trip date range."},400)
            with conn() as c:
                cur=c.execute("INSERT INTO trips(name,start_date,end_date,location,notes,created_at) VALUES(?,?,?,?,?,?)",(name[:160],start,end,str(d.get("location",''))[:200],str(d.get("notes",''))[:1000],datetime.now(timezone.utc).isoformat()))
            return self.send_json({"ok":True,"trip_id":cur.lastrowid},201)
        if p=="/api/trips/tag":
            d=self.body()
            try: trip_id,transaction_id=int(d.get("trip_id",0)),int(d.get("transaction_id",0))
            except (TypeError,ValueError): return self.send_json({"error":"Invalid trip or transaction."},400)
            if not rows("SELECT 1 FROM trips WHERE id=? AND active=1",(trip_id,)) or not rows("SELECT 1 FROM transactions WHERE id=?",(transaction_id,)): return self.send_json({"error":"Trip or transaction not found."},404)
            with conn() as c:
                if d.get("tagged",True): c.execute("INSERT OR IGNORE INTO trip_transactions(trip_id,transaction_id) VALUES(?,?)",(trip_id,transaction_id))
                else: c.execute("DELETE FROM trip_transactions WHERE trip_id=? AND transaction_id=?",(trip_id,transaction_id))
            return self.send_json({"ok":True})
        if p=="/api/audit/action":
            d=self.body(); key=str(d.get("key",''))[:200]; action=str(d.get("action",'')); transaction_id=d.get("transaction_id")
            if not key or action not in ("ignore","exclude"): return self.send_json({"error":"Invalid audit action."},400)
            with conn() as c:
                if action=="exclude":
                    try: transaction_id=int(transaction_id)
                    except (TypeError,ValueError): return self.send_json({"error":"Invalid transaction."},400)
                    if not c.execute("SELECT 1 FROM transactions WHERE id=?",(transaction_id,)).fetchone(): return self.send_json({"error":"Transaction not found."},404)
                    c.execute("UPDATE transactions SET excluded=1 WHERE id=?",(transaction_id,))
                    review_status="Resolved"
                else: review_status="Ignored"
                c.execute("INSERT INTO audit_reviews(finding_key,status,notes,updated_at) VALUES(?,?,?,?) ON CONFLICT(finding_key) DO UPDATE SET status=excluded.status,notes=excluded.notes,updated_at=excluded.updated_at",(key,review_status,str(d.get("notes",''))[:500],datetime.now(timezone.utc).isoformat()))
            return self.send_json({"ok":True})
        if p=="/api/register":
            d=self.body(); account=str(d.get("account","")).strip(); description=str(d.get("description","")).strip(); category=str(d.get("category","Other spending")); notes=str(d.get("notes","")).strip()
            if account not in {x["name"] for x in register_account_summaries()}: return self.send_json({"error":"Choose a USAA or NFCU checking account."},400)
            try:
                entry_date=date.fromisoformat(str(d.get("entryDate",d.get("entry_date","")))).isoformat(); amount=round(float(d.get("amount",0)),2)
            except (TypeError,ValueError): return self.send_json({"error":"Enter a valid purchase date and amount."},400)
            if not description or len(description)>200: return self.send_json({"error":"Enter a description of 200 characters or fewer."},400)
            if amount<=0 or amount>1000000: return self.send_json({"error":"The purchase amount must be greater than zero."},400)
            if category not in CATEGORIES or category in NON_SPENDING_CATEGORIES: return self.send_json({"error":"Choose a spending category."},400)
            if len(notes)>1000: return self.send_json({"error":"The note must be 1,000 characters or fewer."},400)
            with conn() as c:
                cur=c.execute("INSERT INTO register_entries(account,entry_date,description,amount,category,notes,status,created_at) VALUES(?,?,?,?,?,?,?,?)",(account,entry_date,description,amount,category,notes,"Pending",datetime.now(timezone.utc).isoformat()))
                entry_id=cur.lastrowid
            matched=reconcile_register()
            return self.send_json({"ok":True,"id":entry_id,"matched":matched},201)
        if p=="/api/register/status":
            d=self.body()
            try: entry_id=int(d.get("id",0))
            except (TypeError,ValueError): return self.send_json({"error":"Invalid register entry."},400)
            if d.get("status")!="Void": return self.send_json({"error":"Only pending entries can be voided."},400)
            with conn() as c:
                cur=c.execute("UPDATE register_entries SET status='Void' WHERE id=? AND status='Pending'",(entry_id,))
            if not cur.rowcount: return self.send_json({"error":"That entry is no longer pending."},409)
            return self.send_json({"ok":True})
        if p=="/api/register/reconcile":
            return self.send_json({"ok":True,"matched":reconcile_register()})
        if p=="/api/update":
            d=self.body(); table=d.get("table"); allowed={"accounts":{"balance","notes","active"},"bills":{"planned","due_day","paid_from","autopay","status","notes","active"},"one_time_bills":{"amount","due_date","paid_from","status","notes"},"documents":{"document_type","payee","amount","due_date","status","notes","folder_key","active"},"subscriptions":{"amount","frequency","paid_from","still_needed","cancellation_status","notes","active"},"debts":{"balance","minimum","apr","status","notes"},"transactions":{"category","excluded","notes"},"investments":{"balance","contribution","as_of","notes"},"trips":{"name","start_date","end_date","location","notes","active"}}
            field=d.get("field")
            if table not in allowed or field not in allowed[table]: return self.send_json({"error":"Invalid update"},400)
            with conn() as c:
                c.execute(f"UPDATE {table} SET {field}=? WHERE id=?",(d.get("value"),int(d["id"])))
                if table=="subscriptions" and field=="still_needed" and d.get("value")=="No":
                    c.execute("UPDATE subscriptions SET cancellation_status=CASE WHEN cancellation_status='Cancelled' THEN 'Cancelled' ELSE 'Reminder' END WHERE id=?",(int(d["id"]),))
                if table=="transactions" and field=="category":
                    category=d.get("value"); excluded=1 if category in ("Transfer","Income","Debt payment","Investment","Reimbursement","Returned payment") else 0
                    transaction=c.execute("SELECT description FROM transactions WHERE id=?",(int(d["id"]),)).fetchone()
                    c.execute("UPDATE transactions SET excluded=? WHERE id=?",(excluded,int(d["id"])))
                    if transaction and category in CATEGORIES:
                        key=merchant_key(transaction["description"])
                        if key:
                            c.execute("INSERT INTO merchant_rules(merchant_key,sample_description,category,updated_at) VALUES(?,?,?,?) ON CONFLICT(merchant_key) DO UPDATE SET sample_description=excluded.sample_description,category=excluded.category,updated_at=excluded.updated_at",(key,transaction["description"],category,datetime.now(timezone.utc).isoformat()))
                            for match in c.execute("SELECT id,description,excluded FROM transactions").fetchall():
                                if match["id"]!=int(d["id"]) and merchant_key(match["description"])==key:
                                    if category in ("Transfer","Income","Debt payment","Investment","Reimbursement","Returned payment"):
                                        c.execute("UPDATE transactions SET category=?,excluded=1 WHERE id=?",(category,match["id"]))
                                    else:
                                        c.execute("UPDATE transactions SET category=? WHERE id=?",(category,match["id"]))
                            refresh_merchant_rules(c)
                if table=="one_time_bills" and field=="status" and d.get("value")=="Paid":
                    c.execute("UPDATE documents SET status='Filed' WHERE one_time_bill_id=? AND status='Review'",(int(d["id"]),))
            if table=="transactions" and field in ("category","excluded","notes"): reconcile_register()
            return self.send_json({"ok":True})
        if p=="/api/one-time-bills":
            d=self.body()
            if not d.get("name") or not d.get("due_date"): return self.send_json({"error":"Name and due date are required"},400)
            try: amount=float(d.get("amount",0)); datetime.strptime(d["due_date"],"%Y-%m-%d")
            except (ValueError,TypeError): return self.send_json({"error":"Invalid amount or due date"},400)
            with conn() as c: c.execute("INSERT INTO one_time_bills(name,amount,due_date,category,paid_from,status,notes,created_at) VALUES(?,?,?,?,?,?,?,?)",(d["name"].strip(),amount,d["due_date"],d.get("category","Other"),d.get("paid_from","NFCU Bill Pay"),"Unpaid",d.get("notes",""),datetime.now().isoformat(timespec="seconds")))
            return self.send_json({"ok":True},201)
        if p=="/api/documents":
            q=parse_qs(urlparse(self.path).query)
            value=lambda name,default="":str(q.get(name,[default])[0]).strip()
            original_name=Path(value("filename","document")).name[:180]
            document_type=value("document_type","Other")
            payee=value("payee")[:160]; due_date=value("due_date"); notes=value("notes")[:1000]
            folder_key=value("folder_key")[:120]
            category=value("category","Other")[:80]; paid_from=value("paid_from","NFCU Bill Pay")[:100]
            create_bill=value("create_bill").lower() in ("1","true","yes","on")
            if document_type not in ("Bill","Statement","Registration","Insurance","Tax","Receipt","Other"): return self.send_json({"error":"Invalid document type."},400)
            valid_folder_keys={x["key"] for x in document_folders()}
            if folder_key and folder_key not in valid_folder_keys: return self.send_json({"error":"Choose a valid document folder."},400)
            try:
                amount=float(value("amount","0") or 0)
                if amount<0: raise ValueError
                if due_date: datetime.strptime(due_date,"%Y-%m-%d")
            except ValueError: return self.send_json({"error":"Invalid amount or due date."},400)
            if create_bill and (not payee or not due_date): return self.send_json({"error":"A bill name and due date are required to add a payment reminder."},400)
            try: length=int(self.headers.get("Content-Length","0"))
            except ValueError: return self.send_json({"error":"Invalid upload size."},400)
            if length<=0: return self.send_json({"error":"Choose a document to upload."},400)
            if length>MAX_DOCUMENT_BYTES: return self.send_json({"error":"Documents must be 15 MB or smaller."},413)
            content=self.rfile.read(length); detected=document_file_type(content)
            if not detected: return self.send_json({"error":"Only PDF, PNG, JPEG, and WebP documents are accepted."},415)
            extension,mime_type=detected; stored_name=f"{uuid.uuid4().hex}{extension}"; file_path=DOCUMENTS/stored_name; temporary=file_path.with_suffix(file_path.suffix+".part")
            bill_id=None
            try:
                temporary.write_bytes(content); os.chmod(temporary,0o600); os.replace(temporary,file_path)
                with conn() as c:
                    if create_bill:
                        cur=c.execute("INSERT INTO one_time_bills(name,amount,due_date,category,paid_from,status,notes,created_at) VALUES(?,?,?,?,?,?,?,?)",(payee,amount,due_date,category,paid_from,"Unpaid",notes,datetime.now().isoformat(timespec="seconds"))); bill_id=cur.lastrowid
                    if not folder_key:
                        folder_key=infer_document_folder({"original_name":original_name,"payee":payee,"document_type":document_type,"notes":notes},c)
                    cur=c.execute("INSERT INTO documents(original_name,stored_name,mime_type,size,sha256,document_type,payee,amount,due_date,status,notes,folder_key,one_time_bill_id,uploaded_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",(original_name,stored_name,mime_type,len(content),hashlib.sha256(content).hexdigest(),document_type,payee,amount if amount else None,due_date or None,"Review",notes,folder_key,bill_id,datetime.now(timezone.utc).isoformat()))
                    document_id=cur.lastrowid
            except (OSError,sqlite3.Error):
                temporary.unlink(missing_ok=True); file_path.unlink(missing_ok=True)
                return self.send_json({"error":"The document could not be stored safely."},500)
            return self.send_json({"ok":True,"document_id":document_id,"bill_id":bill_id},201)
        if p=="/api/investments":
            d=self.body()
            with conn() as c: c.execute("INSERT INTO investments(name,institution,balance,contribution,as_of,connection,notes) VALUES(?,?,?,?,?,?,?)",(d["name"],d.get("institution",d["name"]),float(d.get("balance",0)),float(d.get("contribution",0)),d.get("as_of",date.today().isoformat()),"Manual",d.get("notes","")))
            return self.send_json({"ok":True},201)
        if p=="/api/import":
            q=parse_qs(urlparse(self.path).query); account=q.get("account",["Imported account"])[0]; filename=q.get("filename",["import"])[0]
            n=int(self.headers.get("Content-Length","0")); data=self.rfile.read(n)
            parsed=parse_ofx(data,account,filename) if filename.lower().endswith((".qfx",".ofx")) else parse_csv_data(data,account,filename)
            added=0
            with conn() as c:
                for r in parsed:
                    fp=hashlib.sha256("|".join(map(str,r[:5])).encode()).hexdigest()
                    cur=c.execute("INSERT OR IGNORE INTO transactions(tx_date,description,amount,category,account,excluded,source,fingerprint) VALUES(?,?,?,?,?,?,?,?)",(*r,fp)); added+=cur.rowcount
            record_subscription_candidates(parsed)
            register_matched=reconcile_register()
            dates=[r[0] for r in parsed]
            return self.send_json({
                "found":len(parsed),
                "added":added,
                "skipped":len(parsed)-added,
                "registerMatched":register_matched,
                "start":min(dates) if dates else None,
                "end":max(dates) if dates else None,
            })
        self.send_json({"error":"Not found"},404)

def main():
    init_db(); threading.Thread(target=automatic_sync_loop,name="plaid-auto-sync",daemon=True).start(); threading.Thread(target=email_reminder_loop,name="email-reminders",daemon=True).start(); print(f"Fine Nance is running at http://{HOST}:{PORT}; Plaid sync every {AUTO_SYNC_HOURS} hours")
    ThreadingHTTPServer((HOST,PORT),Handler).serve_forever()

if __name__=="__main__": main()
