"""Small Plaid REST client. Secrets are supplied only through environment variables."""
from __future__ import annotations

import json
import os
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

BASE_URLS={"sandbox":"https://sandbox.plaid.com","production":"https://production.plaid.com"}

class PlaidError(RuntimeError):
    def __init__(self,message,error_code="PLAID_ERROR",request_id=None):
        super().__init__(message); self.error_code=error_code; self.request_id=request_id

def _secret(env):
    if env == "production":
        return os.environ.get("PLAID_PRODUCTION_SECRET", "")
    return os.environ.get("PLAID_SANDBOX_SECRET") or os.environ.get("PLAID_SECRET", "")

def configured(env=None):
    env = env or environment()
    return bool(os.environ.get("PLAID_CLIENT_ID") and _secret(env) and os.environ.get("HF_TOKEN_KEY"))

def environment():
    value=os.environ.get("PLAID_ENV","sandbox").lower()
    return value if value in BASE_URLS else "sandbox"

def _post(path,payload,env=None):
    env = env or environment()
    if not configured(env): raise PlaidError(f"Plaid {env.title()} credentials have not been configured.","NOT_CONFIGURED")
    body={"client_id":os.environ["PLAID_CLIENT_ID"],"secret":_secret(env),**payload}
    req=Request(BASE_URLS[env]+path,data=json.dumps(body).encode(),headers={"Content-Type":"application/json","Plaid-Version":"2020-09-14"})
    try:
        with urlopen(req,timeout=35) as response: return json.load(response)
    except HTTPError as exc:
        try: detail=json.load(exc)
        except Exception: detail={}
        raise PlaidError(detail.get("error_message","Plaid rejected the request."),detail.get("error_code","HTTP_ERROR"),detail.get("request_id")) from None
    except (URLError,TimeoutError):
        raise PlaidError("Plaid could not be reached. Check the VM internet connection.","NETWORK_ERROR") from None

def create_link_token(client_user_id,env=None):
    return _post("/link/token/create",{"client_name":"Fine Nance","language":"en","country_codes":["US"],"products":["transactions"],"transactions":{"days_requested":365},"user":{"client_user_id":client_user_id}},env)

def exchange_public_token(public_token,env=None):
    return _post("/item/public_token/exchange",{"public_token":public_token},env)

def accounts_get(access_token,env=None):
    return _post("/accounts/get",{"access_token":access_token},env)

def transactions_sync(access_token,cursor=None,env=None):
    original=cursor; attempts=0
    while True:
        attempts+=1; current=original; out={"added":[],"modified":[],"removed":[],"accounts":[],"next_cursor":original}
        try:
            while True:
                payload={"access_token":access_token,"count":500,"options":{"include_original_description":True,"personal_finance_category_version":"v2"}}
                if current: payload["cursor"]=current
                page=_post("/transactions/sync",payload,env)
                for key in ("added","modified","removed"): out[key].extend(page.get(key,[]))
                out["accounts"]=page.get("accounts",out["accounts"]); current=page.get("next_cursor",current); out["next_cursor"]=current
                if not page.get("has_more"): return out
        except PlaidError as exc:
            if exc.error_code=="TRANSACTIONS_SYNC_MUTATION_DURING_PAGINATION" and attempts<3: continue
            raise

def encrypt_token(token):
    from cryptography.fernet import Fernet
    key=os.environ.get("HF_TOKEN_KEY")
    if not key: raise PlaidError("Token encryption key is missing.","NO_ENCRYPTION_KEY")
    return Fernet(key.encode()).encrypt(token.encode()).decode()

def decrypt_token(token):
    from cryptography.fernet import Fernet, InvalidToken
    try: return Fernet(os.environ["HF_TOKEN_KEY"].encode()).decrypt(token.encode()).decode()
    except (KeyError,InvalidToken,ValueError): raise PlaidError("The stored connection token could not be decrypted.","TOKEN_DECRYPTION_FAILED") from None
