"""Private, on-device receipt OCR and conservative field extraction."""

from __future__ import annotations

import re
from datetime import date, datetime, timedelta


MONEY_RE = re.compile(r"(?<![\d/])\$?\s*(\d{1,6}(?:,\d{3})*\.\d{2})\s*$")
DATE_PATTERNS = (
    re.compile(r"\b(20\d{2})[-/.](\d{1,2})[-/.](\d{1,2})\b"),
    re.compile(r"\b(\d{1,2})[-/.](\d{1,2})[-/.](20\d{2}|\d{2})\b"),
)
TOTAL_WORDS = re.compile(r"\b(?:grand\s+total|amount\s+due|balance\s+due|total)\b", re.I)
NON_ITEM_WORDS = re.compile(
    r"\b(?:sub\s*total|total|tax|change|cash|credit|debit|visa|mastercard|amex|"
    r"tender|payment|balance|amount due|discount|coupon|savings|auth|approval|"
    r"items? sold|member|receipt|store|phone|tel|thank you)\b",
    re.I,
)


def normalize_item_name(value: str) -> str:
    value = re.sub(r"[^a-z0-9]+", " ", str(value or "").lower())
    return " ".join(value.split())[:240]


def _valid_date(year: int, month: int, day: int) -> str | None:
    if year < 100:
        year += 2000
    try:
        parsed = date(year, month, day)
    except ValueError:
        return None
    if parsed > date.today() + timedelta(days=366):
        return None
    return parsed.isoformat()


def _find_date(lines: list[str]) -> str | None:
    for line in lines:
        for index, pattern in enumerate(DATE_PATTERNS):
            match = pattern.search(line)
            if not match:
                continue
            a, b, c = (int(x) for x in match.groups())
            found = _valid_date(a, b, c) if index == 0 else _valid_date(c, a, b)
            if found:
                return found
        for fmt in ("%b %d, %Y", "%B %d, %Y", "%b %d %Y", "%B %d %Y"):
            try:
                candidate = re.search(r"[A-Za-z]{3,9}\s+\d{1,2},?\s+20\d{2}", line)
                if candidate:
                    return datetime.strptime(candidate.group(0).replace(",", ""), fmt.replace(",", "")).date().isoformat()
            except ValueError:
                pass
    return None


def _money_at_end(line: str) -> float | None:
    match = MONEY_RE.search(line.replace("O.", "0."))
    if not match:
        return None
    try:
        return round(float(match.group(1).replace(",", "")), 2)
    except ValueError:
        return None


def _find_total(lines: list[str]) -> float | None:
    candidates = []
    for index, line in enumerate(lines):
        amount = _money_at_end(line)
        if amount is None or re.search(r"\bsub\s*total\b", line, re.I):
            continue
        if TOTAL_WORDS.search(line):
            priority = 3 if re.search(r"grand\s+total|amount\s+due|balance\s+due", line, re.I) else 2
            candidates.append((priority, index, amount))
    if candidates:
        return max(candidates, key=lambda value: (value[0], value[1]))[2]
    amounts = [amount for line in lines for amount in [_money_at_end(line)] if amount is not None]
    return max(amounts) if amounts else None


def _find_tax(lines: list[str]) -> float | None:
    for line in lines:
        if re.search(r"\b(?:sales\s+)?tax\b", line, re.I):
            amount = _money_at_end(line)
            if amount is not None:
                return amount
    return None


def _find_merchant(lines: list[str]) -> str:
    rejected = re.compile(r"\b(?:receipt|invoice|welcome|thank|www\.|https?://|cashier|register)\b", re.I)
    for line in lines[:10]:
        cleaned = re.sub(r"\s+", " ", line).strip(" -*#")
        if len(cleaned) < 3 or len(cleaned) > 80 or rejected.search(cleaned):
            continue
        if MONEY_RE.search(cleaned) or DATE_PATTERNS[0].search(cleaned) or DATE_PATTERNS[1].search(cleaned):
            continue
        if re.search(r"\b\d{5}(?:-\d{4})?\b|\(?\d{3}\)?[- .]\d{3}[- .]\d{4}", cleaned):
            continue
        if sum(ch.isalpha() for ch in cleaned) >= 3:
            return cleaned[:160]
    return "Receipt purchase"


def _find_items(lines: list[str]) -> list[dict]:
    items = []
    for line in lines:
        amount = _money_at_end(line)
        if amount is None or NON_ITEM_WORDS.search(line):
            continue
        name = MONEY_RE.sub("", line).strip(" .:-*$#")
        name = re.sub(r"^\d{5,}\s+", "", name)
        name = re.sub(r"\s{2,}", " ", name).strip()
        if len(name) < 2 or not re.search(r"[A-Za-z]", name):
            continue
        quantity = 1.0
        qty_match = re.search(r"\b(\d+(?:\.\d+)?)\s*(?:@|x)\s*\$?\d", name, re.I)
        if qty_match:
            quantity = float(qty_match.group(1))
            name = name[: qty_match.start()].strip(" .:-") or name
        normalized = normalize_item_name(name)
        if not normalized:
            continue
        items.append({"name": name[:240], "normalized_name": normalized, "quantity": quantity, "total": amount})
    return items[:200]


def parse_receipt_lines(lines: list[str], scores: list[float] | None = None) -> dict:
    cleaned = [re.sub(r"\s+", " ", str(line or "")).strip() for line in lines]
    cleaned = [line for line in cleaned if line]
    confidence = None
    if scores:
        valid = [float(score) for score in scores if score is not None]
        confidence = round(sum(valid) / len(valid), 3) if valid else None
    return {
        "merchant": _find_merchant(cleaned),
        "purchase_date": _find_date(cleaned),
        "total": _find_total(cleaned),
        "tax": _find_tax(cleaned),
        "items": _find_items(cleaned),
        "raw_text": "\n".join(cleaned)[:100000],
        "confidence": confidence,
    }


def ocr_rows(texts, boxes, scores=None):
    """Reassemble OCR fragments that share a visual row on the receipt."""
    fragments=[]
    for index,text in enumerate(texts or []):
        try:
            points=boxes[index]
            xs=[float(point[0]) for point in points]; ys=[float(point[1]) for point in points]
            fragments.append({"text":str(text),"x":min(xs),"y":sum(ys)/len(ys),"height":max(ys)-min(ys),"score":float(scores[index]) if scores is not None else None})
        except (IndexError,TypeError,ValueError):
            fragments.append({"text":str(text),"x":0.0,"y":float(index)*100.0,"height":40.0,"score":float(scores[index]) if scores is not None else None})
    fragments.sort(key=lambda item:(item["y"],item["x"]))
    grouped=[]
    for fragment in fragments:
        row=next((candidate for candidate in reversed(grouped[-3:]) if abs(candidate["y"]-fragment["y"])<=max(10.0,candidate["height"],fragment["height"])*0.6),None)
        if row is None:
            grouped.append({"y":fragment["y"],"height":fragment["height"],"parts":[fragment]})
        else:
            row["parts"].append(fragment)
            row["y"]=(row["y"]*(len(row["parts"])-1)+fragment["y"])/len(row["parts"])
            row["height"]=max(row["height"],fragment["height"])
    lines=[]; line_scores=[]
    for row in grouped:
        parts=sorted(row["parts"],key=lambda item:item["x"])
        lines.append(" ".join(part["text"].strip() for part in parts if part["text"].strip()))
        valid=[part["score"] for part in parts if part["score"] is not None]
        line_scores.append(sum(valid)/len(valid) if valid else None)
    return lines,line_scores


def extract_receipt(content: bytes, mime_type: str) -> dict:
    """Run bundled OCR without network access and return parsed receipt fields."""
    image_content = content
    if mime_type == "application/pdf":
        import fitz

        document = fitz.open(stream=content, filetype="pdf")
        if not document.page_count:
            raise ValueError("The PDF has no pages.")
        page = document.load_page(0)
        image_content = page.get_pixmap(matrix=fitz.Matrix(2.0, 2.0), alpha=False).tobytes("png")
        document.close()

    from rapidocr import RapidOCR

    result = RapidOCR(params={"Rec.lang_type": "en"})(image_content)
    lines, scores = ocr_rows(result.txts, result.boxes, result.scores)
    if not lines:
        raise ValueError("No readable receipt text was found.")
    return parse_receipt_lines(lines, scores)
