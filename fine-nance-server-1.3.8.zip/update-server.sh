#!/usr/bin/env bash
set -euo pipefail

app_dir="${FINE_NANCE_APP_DIR:-/opt/harrington-finance/app}"
package_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"

if [[ ! -f "$package_dir/server.py" || ! -f "$package_dir/VERSION" || ! -f "$package_dir/Dockerfile" ]]; then
  echo "The Fine Nance server update package is incomplete." >&2
  exit 1
fi
if [[ ! -d "$app_dir" || ! -f "$app_dir/compose.yaml" ]]; then
  echo "Fine Nance was not found at $app_dir." >&2
  exit 1
fi

stamp="$(date -u +%Y%m%d-%H%M%S)"
backup_dir="$app_dir/update-backups/$stamp"
mkdir -p "$backup_dir"
for name in auth.py compose.yaml Dockerfile plaid_connector.py receipt_ocr.py requirements.txt server.py VERSION static; do
  if [[ -e "$app_dir/$name" ]]; then cp -a "$app_dir/$name" "$backup_dir/"; fi
done

for name in auth.py compose.yaml Dockerfile plaid_connector.py receipt_ocr.py requirements.txt server.py VERSION; do
  cp -f "$package_dir/$name" "$app_dir/$name"
done
mkdir -p "$app_dir/static"
cp -a "$package_dir/static/." "$app_dir/static/"

cd "$app_dir"
docker compose up -d --build
for _ in $(seq 1 30); do
  if curl -fsS http://127.0.0.1:8765/api/auth/status >/dev/null; then
    echo "Fine Nance $(cat VERSION) is running. Backup: $backup_dir"
    exit 0
  fi
  sleep 1
done
echo "The container rebuilt, but Fine Nance did not become healthy within 30 seconds." >&2
exit 1
