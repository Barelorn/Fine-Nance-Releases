import base64, hashlib, hmac, io, os, secrets, struct, time
from datetime import datetime, timedelta, timezone

SESSION_HOURS = 8

def password_hash(password, salt=None):
    salt = salt or os.urandom(16)
    digest = hashlib.scrypt(password.encode(), salt=salt, n=2**15, r=8, p=1, dklen=32, maxmem=64*1024*1024)
    return f"scrypt$32768$8$1${base64.b64encode(salt).decode()}${base64.b64encode(digest).decode()}"

def password_ok(password, encoded):
    try:
        _, n, r, p, salt, expected = encoded.split("$")
        actual = hashlib.scrypt(password.encode(), salt=base64.b64decode(salt), n=int(n), r=int(r), p=int(p), dklen=32, maxmem=64*1024*1024)
        return hmac.compare_digest(actual, base64.b64decode(expected))
    except Exception:
        return False

def new_totp_secret():
    return base64.b32encode(os.urandom(20)).decode().rstrip("=")

def totp(secret, at=None):
    at = int(at or time.time()); counter = at // 30
    key = base64.b32decode(secret + "=" * ((8-len(secret)%8)%8), casefold=True)
    digest = hmac.new(key, struct.pack(">Q", counter), hashlib.sha1).digest()
    offset = digest[-1] & 15
    return str((struct.unpack(">I", digest[offset:offset+4])[0] & 0x7fffffff) % 1_000_000).zfill(6)

def totp_ok(secret, code):
    code = str(code or "").strip()
    return len(code)==6 and code.isdigit() and any(hmac.compare_digest(totp(secret, time.time()+step*30), code) for step in (-1,0,1))

def qr_data_uri(uri):
    import qrcode
    image=qrcode.make(uri); out=io.BytesIO(); image.save(out, format="PNG")
    return "data:image/png;base64,"+base64.b64encode(out.getvalue()).decode()

def new_session():
    token=secrets.token_urlsafe(32); csrf=secrets.token_urlsafe(24)
    expires=(datetime.now(timezone.utc)+timedelta(hours=SESSION_HOURS)).isoformat()
    return token, hashlib.sha256(token.encode()).hexdigest(), csrf, expires

def token_hash(token): return hashlib.sha256(token.encode()).hexdigest()
