param([Parameter(Mandatory=$true)][string]$PackagePath,[Parameter(Mandatory=$true)][string]$ExpectedSha256,[Parameter(Mandatory=$true)][int]$ServerPid,[Parameter(Mandatory=$true)][string]$InstallRoot)
$ErrorActionPreference='Stop'
$appRoot=Join-Path $InstallRoot 'app'; $dataRoot=Join-Path $appRoot 'data'; $backupRoot=Join-Path $InstallRoot 'update-backups'; $stamp=Get-Date -Format 'yyyyMMdd-HHmmss'; $backup=Join-Path $backupRoot $stamp; $stage=Join-Path $env:TEMP "FineNance-Update-$stamp"
try {
  $actual=(Get-FileHash -LiteralPath $PackagePath -Algorithm SHA256).Hash.ToLowerInvariant()
  if($actual -ne $ExpectedSha256.ToLowerInvariant()){throw 'The update checksum did not match. Nothing was installed.'}
  New-Item -ItemType Directory -Path $stage,$backup -Force|Out-Null; Expand-Archive -LiteralPath $PackagePath -DestinationPath $stage -Force
  $payload=Join-Path $stage 'app'
  if(-not(Test-Path(Join-Path $payload 'server.py')) -or -not(Test-Path(Join-Path $payload 'VERSION'))){throw 'The update package is incomplete.'}
  if(Test-Path $dataRoot){Copy-Item -LiteralPath $dataRoot -Destination (Join-Path $backup 'data') -Recurse -Force}
  foreach($name in @('server.py','auth.py','plaid_connector.py','requirements.txt','VERSION','update_runner.ps1','static')){$source=Join-Path $appRoot $name;if(Test-Path $source){Copy-Item -LiteralPath $source -Destination $backup -Recurse -Force}}
  try{Stop-Process -Id $ServerPid -Force -ErrorAction SilentlyContinue}catch{}; Start-Sleep -Seconds 2
  Get-ChildItem -LiteralPath $payload -Force|Where-Object Name -ne 'data'|ForEach-Object{$target=Join-Path $appRoot $_.Name;if(Test-Path $target){Remove-Item -LiteralPath $target -Recurse -Force};Copy-Item -LiteralPath $_.FullName -Destination $target -Recurse -Force}
  $python=Join-Path $InstallRoot 'venv\Scripts\python.exe';if(Test-Path $python){& $python -m pip install --disable-pip-version-check --quiet -r (Join-Path $appRoot 'requirements.txt')}
  Start-Process 'powershell.exe' -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',(Join-Path $InstallRoot 'Start-FineNance.ps1')) -WindowStyle Hidden
}catch{New-Item -ItemType Directory -Path $backupRoot -Force|Out-Null;$_|Out-File -LiteralPath (Join-Path $backupRoot "update-error-$stamp.txt") -Encoding UTF8}finally{Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue;Remove-Item -LiteralPath $PackagePath -Force -ErrorAction SilentlyContinue}
