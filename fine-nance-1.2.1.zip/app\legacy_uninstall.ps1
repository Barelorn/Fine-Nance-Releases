$ErrorActionPreference = "Stop"

$appRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$installRoot = Split-Path -Parent $appRoot
$pidPath = Join-Path $installRoot "FineNance.pid"
$preservedRoot = Join-Path $installRoot "preserved-data"
$dataPath = Join-Path $appRoot "data"

if (Test-Path -LiteralPath $pidPath) {
    $serverPid = [int](Get-Content -LiteralPath $pidPath -Raw)
    Stop-Process -Id $serverPid -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 1
}

if (Test-Path -LiteralPath $dataPath) {
    if (Test-Path -LiteralPath $preservedRoot) {
        $preservedRoot = Join-Path $installRoot ("preserved-data-" + (Get-Date -Format "yyyyMMdd-HHmmss"))
    }
    Move-Item -LiteralPath $dataPath -Destination $preservedRoot
}

Remove-Item -LiteralPath (Join-Path ([Environment]::GetFolderPath("Desktop")) "Fine Nance.lnk") -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\FineNance" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath (Join-Path $installRoot "venv") -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath $appRoot -Recurse -Force -ErrorAction SilentlyContinue

Write-Host "Fine Nance was removed. Personal data was preserved at:" -ForegroundColor Green
Write-Host $preservedRoot
Read-Host "Press Enter to close"
